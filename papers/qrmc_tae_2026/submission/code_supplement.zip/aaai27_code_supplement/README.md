# Code & Data Supplement — Q/R/M/C: A Stage-Decomposition Evaluation Protocol for Memory-Based Agents (AAAI-27 submission)

Anonymized code and data for all experiments reported in the paper and
the Technical Supplement. Python 3.9; run everything from the archive
root with `PYTHONPATH=.`.

## Setup

```bash
python3.9 -m venv .venv && .venv/bin/pip install -r requirements.txt
```

LLM experiments additionally require a local Ollama server with models
`llama3.1:latest` and `qwen3:4b` (for qwen, thinking is disabled
request-level via `extra_body={"think": false}`; recorded in the
registrations for budget parity).

## Map: paper section → code → data

| Paper section | Code | Data (included) |
|---|---|---|
| Single agent (oracle interventions) | `scripts/benchmark_oracle_stage_interventions.py`, `scripts/analyze_oracle_pairing.py` | `data/oracle/` (per-seed rows, bootstrap aggregate) |
| Single agent (retrieval inspection, 91%) | `experiments/v2_retriever/` | see `experiments/v2_retriever/RESULTS.md` |
| Multi-agent sweep (35,640 runs) | `experiments/big_experiment/` (`runner.py`, `analyze_effect_sizes.py`, `analyze_fig_cis.py`) | `data/multiagent_sweep/runs.csv`, `fig_aggregates.json` |
| Threshold robustness (θ, ε) | `experiments/big_experiment/exp_eps_sensitivity.py`, θ-ablation in `scripts/` | `data/eps_sensitivity_out.txt` |
| Provenance stratification (φ, warps) | `experiments/warp/` (`warp_instrumentation.py`, `exp_warp_gain.py`, `phi_sensitivity.py`) | `data/warp/` (strata, φ-sensitivity, reservation-protocol results) |
| Learned baselines | `experiments/commnet_baseline/`, `experiments/commnet_ppo_baseline/` | `RESULTS.md` in each |
| LLM collective | `experiments/llm_collective/` | `RESULTS.md` |
| Third-party stacks (external validation) | `experiments/qrmc_external/` (`memory_house.py`, `run_external_validation.py`) | `data/qrmc_external/` (registrations, per-episode rows, summaries, both models) |
| Blinded fault localization | `experiments/qrmc_external/run_meta_evaluation.py` | `data/qrmc_external/registered_meta.json`, `rows_meta_*.json`, `meta_verdict_*.json` |
| VMAS check | `experiments/vmas_portability/` | `RESULTS.md` |
| Paper figures | `scripts/make_paper_figures_v3.py`, `experiments/qrmc_external/make_external_figure.py`, `experiments/warp/make_*_figures.py` | reads `data/` outputs |

## Registered predictions

All predictions were written to `registered*.json` files before the
corresponding runs; files in `data/qrmc_external/` include the
revision history of the event-semantics adapter (v1→v3) and of the
blinded-localization decision rule (thresholds fixed pre-run).
Registered failures are reported in the paper together with their
mechanisms.

## Determinism

Seeds are set explicitly in every runner (`stable_rng`, per-seed
`default_rng` streams); the sweep and the fault-injection studies are
resumable via per-episode checkpoints (`rows_*.json`). LLM runs use
temperature 0; residual serving nondeterminism is possible.

## Core library

`songline_drive/` implements the instrumented stack: scene encoding,
semantic tags, graph memory, intent-conditioned retrieval, target
materialization (lock), waypoint controller, and the collective layer
(`collective_*.py`: merge, trust weighting, temporal decay,
staleness gate) with the peer/bus/central/independent architectures.

## License

MIT (see LICENSE; the repository originated from the Active Neural
SLAM codebase, whose attribution is retained).

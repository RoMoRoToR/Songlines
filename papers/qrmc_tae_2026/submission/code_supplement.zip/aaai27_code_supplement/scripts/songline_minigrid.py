import argparse
import csv
import json
import os
import re
from collections import deque

import gymnasium as gym
import matplotlib.pyplot as plt
import minigrid
import numpy as np
from minigrid.core.world_object import Ball, Box, Goal

from songline_drive.agent_state import AgentState, IntentPolicy, update_agent_state
from songline_drive.graph_memory import DynamicSonglineGraph
from songline_drive.graph_rollout import GraphRolloutPlanner
from songline_drive.intents import build_planner_query
from songline_drive.maneuver_selector import ManeuverSelector
from songline_drive.scene_encoder import MiniGridSceneEncoder
from songline_drive.symbolic_memory import SymbolicMemory
from songline_drive.scene_tokenizer import SceneTokenizer
from songline_drive.trajectory_planner import TrajectoryPlanner
from songline_drive.types import IntentType
from utils.lz_memory import SymbolicTokenizer


BABYAI_INTENT_MAP = {
    "go to the blue ball": "find_water_source",
    "go to the grey ball": "find_water_source",
    "go to the gray ball": "find_water_source",
    "go to the grey box": "find_safe_rest_zone",
    "go to the gray box": "find_safe_rest_zone",
    "go to the green door": "find_goal_region",
    "go to the red key": "hazard_recovery_exit",
}

BABYAI_OBJECT_TYPE_TO_INTENT = {
    "ball": "find_water_source",
    "box": "find_safe_rest_zone",
    "door": "find_goal_region",
    "key": "hazard_recovery_exit",
}


def ensure_dir(path: str):
    os.makedirs(path, exist_ok=True)


def local_symbolic_observation(env, radius=1):
    """
    Строит компактное символическое наблюдение:
    - направление агента
    - локальное окно (2r+1)x(2r+1) вокруг агента
    - тип клетки кодируется коротким числом
    """
    unwrapped = env.unwrapped
    ax, ay = unwrapped.agent_pos
    direction = unwrapped.agent_dir
    grid = unwrapped.grid

    patch = []
    for dy in range(-radius, radius + 1):
        row = []
        for dx in range(-radius, radius + 1):
            x = ax + dx
            y = ay + dy
            if x < 0 or y < 0 or x >= grid.width or y >= grid.height:
                row.append(99)
                continue
            cell = grid.get(x, y)
            if cell is None:
                row.append(0)
            else:
                cell_name = cell.type
                if cell_name == "wall":
                    row.append(1)
                elif cell_name == "goal":
                    row.append(2)
                elif cell_name == "lava":
                    row.append(3)
                elif cell_name == "door":
                    row.append(4)
                elif cell_name == "key":
                    row.append(5)
                elif cell_name == "ball":
                    row.append(6)
                elif cell_name == "box":
                    row.append(7)
                else:
                    row.append(8)
        patch.append(row)

    patch = np.array(patch, dtype=np.int32).reshape(-1)
    obs_vec = np.concatenate([np.array([direction], dtype=np.int32), patch])
    return obs_vec.astype(np.float32)


def scene_token_to_int(scene_token):
    token_name = str(scene_token.token_type)
    return sum((idx + 1) * ord(ch) for idx, ch in enumerate(token_name))


def maybe_perturb_scene_token(scene_token, args, rng):
    if scene_token is None:
        return None
    dropout_prob = float(getattr(args, "semantic_tag_dropout_prob", 0.0))
    false_positive_prob = float(getattr(args, "semantic_tag_false_positive_prob", 0.0))
    false_positive_value = float(getattr(args, "semantic_tag_false_positive_value", 0.35))
    if dropout_prob <= 0.0 and false_positive_prob <= 0.0:
        return scene_token

    semantic_tags = dict(getattr(scene_token, "semantic_tags", {}) or {})
    if not semantic_tags:
        return scene_token

    perturbed = dict(semantic_tags)
    if dropout_prob > 0.0:
        for tag_name, value in list(perturbed.items()):
            if float(value) > 0.0 and float(rng.rand()) < dropout_prob:
                perturbed[tag_name] = 0.0

    if false_positive_prob > 0.0:
        for tag_name, value in list(perturbed.items()):
            if float(value) <= 0.0 and float(rng.rand()) < false_positive_prob:
                perturbed[tag_name] = float(false_positive_value)

    if perturbed == semantic_tags:
        return scene_token

    scene_token.semantic_tags = perturbed
    return scene_token


def manhattan(a, b):
    return int(abs(int(a[0]) - int(b[0])) + abs(int(a[1]) - int(b[1])))


def random_safe_action(rng):
    return int(rng.choice([0, 1, 2]))


def get_goal_position(env):
    target_xy = getattr(env, "semantic_target_pos", None)
    if target_xy is not None:
        return np.asarray(target_xy, dtype=np.int32).copy()
    grid = env.unwrapped.grid
    for y in range(grid.height):
        for x in range(grid.width):
            cell = grid.get(x, y)
            if cell is not None and cell.type == "goal":
                return np.array([x, y], dtype=np.int32)
    return None


def get_water_position(env):
    target_xy = getattr(env, "semantic_target_pos", None)
    if target_xy is not None and str(getattr(env, "current_intent", "")) == "find_water_source":
        return np.asarray(target_xy, dtype=np.int32).copy()
    water_xy = getattr(env, "water_pos", None)
    if water_xy is not None:
        return np.asarray(water_xy, dtype=np.int32).copy()
    grid = env.unwrapped.grid
    for y in range(grid.height):
        for x in range(grid.width):
            cell = grid.get(x, y)
            if cell is not None and cell.type == "ball":
                return np.array([x, y], dtype=np.int32)
    return None


def get_rest_position(env):
    target_xy = getattr(env, "semantic_target_pos", None)
    if target_xy is not None and str(getattr(env, "current_intent", "")) == "find_safe_rest_zone":
        return np.asarray(target_xy, dtype=np.int32).copy()
    rest_xy = getattr(env, "rest_pos", None)
    if rest_xy is not None:
        return np.asarray(rest_xy, dtype=np.int32).copy()
    grid = env.unwrapped.grid
    for y in range(grid.height):
        for x in range(grid.width):
            cell = grid.get(x, y)
            if cell is not None and cell.type == "box":
                return np.array([x, y], dtype=np.int32)
    return None


def _grid_cell_code(env, x: int, y: int) -> int:
    grid = env.unwrapped.grid
    if x < 0 or y < 0 or x >= grid.width or y >= grid.height:
        return 99
    cell = grid.get(x, y)
    if cell is None:
        return 0
    if cell.type == "wall":
        return 1
    if cell.type == "goal":
        return 2
    if cell.type == "lava":
        return 3
    if cell.type == "door":
        return 4
    if cell.type == "ball":
        return 6
    if cell.type == "box":
        return 7
    return 8


def _passable_cell_code(cell_code: int) -> bool:
    return int(cell_code) in (0, 2, 4, 6, 7, 8)


def _oracle_shortest_path_next_cell(env, target_xy):
    if target_xy is None:
        return None
    start = tuple(int(v) for v in np.asarray(env.unwrapped.agent_pos, dtype=np.int32))
    goal = tuple(int(v) for v in np.asarray(target_xy, dtype=np.int32))
    if start == goal:
        return goal
    grid = env.unwrapped.grid
    queue = deque([start])
    parents = {start: None}
    while queue:
        x, y = queue.popleft()
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            nx = int(x + dx)
            ny = int(y + dy)
            nxt = (nx, ny)
            if nxt in parents:
                continue
            if nx < 0 or ny < 0 or nx >= grid.width or ny >= grid.height:
                continue
            if not _passable_cell_code(_grid_cell_code(env, nx, ny)):
                continue
            parents[nxt] = (x, y)
            if nxt == goal:
                queue.clear()
                break
            queue.append(nxt)
    if goal not in parents:
        return None
    current = goal
    while parents[current] is not None and parents[current] != start:
        current = parents[current]
    return np.asarray(current, dtype=np.int32)


def _oracle_controller_action(env, trajectory_planner, target_xy):
    if target_xy is None:
        return random_safe_action(np.random.RandomState(0))
    next_xy = _oracle_shortest_path_next_cell(env, target_xy)
    waypoint_xy = target_xy if next_xy is None else next_xy
    return trajectory_planner.next_action(
        env,
        {"command_type": "go_to_waypoint", "waypoint_xy": tuple(int(v) for v in np.asarray(waypoint_xy, dtype=np.int32))},
    )


def select_oracle_semantic_waypoint(args, env, active_intent_type, goal_xy, water_xy, rest_xy):
    intent_name = None if active_intent_type is None else str(getattr(active_intent_type, "value", active_intent_type))
    if intent_name == "find_goal_region":
        if goal_xy is not None:
            return np.asarray(goal_xy, dtype=np.int32).copy(), "oracle_goal_region"
        return None, "oracle_goal_region_missing"
    if intent_name == "hazard_recovery_exit":
        if goal_xy is not None:
            stable = _stable_goal_rejoin_waypoint(env, goal_xy, avoid_hazard_adjacent=True, max_radius=4)
            if stable is not None:
                return np.asarray(stable, dtype=np.int32).copy(), "oracle_stable_rejoin"
            return np.asarray(goal_xy, dtype=np.int32).copy(), "oracle_goal_fallback"
        return None, "oracle_hazard_missing"
    if intent_name == "find_water_source":
        if water_xy is not None:
            return np.asarray(water_xy, dtype=np.int32).copy(), "oracle_water"
        return None, "oracle_water_missing"
    if intent_name == "find_safe_rest_zone":
        if rest_xy is not None:
            return np.asarray(rest_xy, dtype=np.int32).copy(), "oracle_rest"
        return None, "oracle_rest_missing"
    return None, "oracle_not_applicable"


def make_oracle_path_plan(waypoint_xy, planner_query, source):
    if waypoint_xy is None:
        return None
    waypoint_xy = np.asarray(waypoint_xy, dtype=np.int32).copy()
    return {
        "waypoint_xy": waypoint_xy,
        "graph_path_length": 0,
        "target_node_id": None,
        "next_node_id": None,
        "maneuver_command": {
            "command_type": "go_to_waypoint",
            "waypoint_xy": tuple(int(v) for v in waypoint_xy),
        },
        "planner_debug": {
            "used_intent_query": bool(planner_query is not None),
            "intent_type": None if planner_query is None else str(getattr(planner_query.intent_type, "value", planner_query.intent_type)),
            "query_tag_name": None if planner_query is None or getattr(planner_query, "target_predicate", None) is None else planner_query.target_predicate.tag_name,
            "candidate_node_ids": [],
            "candidate_base_utilities": {},
            "candidate_tag_confidences": {},
            "candidate_intent_scores": {},
            "selected_tag_confidence": None,
            "selected_node_semantic_tag_confidence": {},
            "selected_plan_utility": 1.0,
            "plan_source": str(source),
            "goal_rejoin_target_materialized": True,
            "goal_rejoin_target_source": str(source),
        },
    }


def local_resource_guidance(env, scene, active_intent_type, radius: int = 1):
    if scene is None or active_intent_type is None:
        return None
    intent_name = str(getattr(active_intent_type, "value", active_intent_type))
    risk = scene.risk_features
    resource_type = None
    has_evidence = False
    if intent_name == "find_water_source":
        resource_type = "ball"
        has_evidence = bool(
            float(risk.get("water_visible", 0.0)) > 0.0
            or float(risk.get("water_accessible", 0.0)) > 0.0
        )
    elif intent_name == "find_safe_rest_zone":
        resource_type = "box"
        has_evidence = bool(
            float(risk.get("rest_visible", 0.0)) > 0.0
            or float(risk.get("rest_accessible", 0.0)) > 0.0
        )
    if resource_type is None or not has_evidence:
        return None

    agent_xy = np.asarray(env.unwrapped.agent_pos, dtype=np.int32)
    grid = env.unwrapped.grid
    resource_positions = []
    for dy in range(-radius, radius + 1):
        for dx in range(-radius, radius + 1):
            x = int(agent_xy[0] + dx)
            y = int(agent_xy[1] + dy)
            if x < 0 or y < 0 or x >= grid.width or y >= grid.height:
                continue
            cell = grid.get(x, y)
            if cell is not None and cell.type == resource_type:
                resource_positions.append((x, y))
    if not resource_positions:
        return None

    for rx, ry in resource_positions:
        if manhattan(agent_xy, (rx, ry)) <= 1:
            return {
                "hold_position": True,
                "waypoint_xy": tuple(int(v) for v in agent_xy),
                "resource_xy": (int(rx), int(ry)),
                "resource_type": resource_type,
            }

    candidates = []
    for rx, ry in resource_positions:
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            nx = int(rx + dx)
            ny = int(ry + dy)
            cell_code = _grid_cell_code(env, nx, ny)
            if cell_code not in (0, 2):
                continue
            candidates.append(
                (
                    manhattan(agent_xy, (nx, ny)),
                    manhattan((nx, ny), (rx, ry)),
                    ny,
                    nx,
                    (nx, ny),
                    (rx, ry),
                )
            )
    if not candidates:
        return None
    candidates.sort()
    _, _, _, _, waypoint_xy, resource_xy = candidates[0]
    return {
        "hold_position": False,
        "waypoint_xy": tuple(int(v) for v in waypoint_xy),
        "resource_xy": tuple(int(v) for v in resource_xy),
        "resource_type": resource_type,
    }


class WaterTaskWrapper(gym.Wrapper):
    def __init__(self, env, success_radius: int = 1, success_reward: float = 1.0):
        super().__init__(env)
        self.success_radius = max(1, int(success_radius))
        self.success_reward = float(success_reward)
        self.water_pos = None

    def _find_cells(self, cell_type: str):
        cells = []
        grid = self.unwrapped.grid
        for y in range(grid.height):
            for x in range(grid.width):
                cell = grid.get(x, y)
                if cell is not None and cell.type == cell_type:
                    cells.append((int(x), int(y)))
        return cells

    def _fallback_water_position(self):
        grid = self.unwrapped.grid
        agent_xy = tuple(int(v) for v in self.unwrapped.agent_pos)
        candidates = []
        for y in range(1, grid.height - 1):
            for x in range(1, grid.width - 1):
                if (x, y) == agent_xy:
                    continue
                cell = grid.get(x, y)
                if cell is None:
                    dist = abs(x - agent_xy[0]) + abs(y - agent_xy[1])
                    candidates.append((dist, y, x))
        if not candidates:
            return None
        candidates.sort(key=lambda item: (-item[0], item[1], item[2]))
        return int(candidates[0][2]), int(candidates[0][1])

    def _install_water_marker(self):
        grid = self.unwrapped.grid
        goal_cells = self._find_cells("goal")
        for gx, gy in goal_cells:
            grid.set(int(gx), int(gy), None)
        if goal_cells:
            wx, wy = goal_cells[0]
        else:
            fallback = self._fallback_water_position()
            if fallback is None:
                self.water_pos = None
                return
            wx, wy = fallback
        grid.set(int(wx), int(wy), Ball(color="blue"))
        self.water_pos = np.array([int(wx), int(wy)], dtype=np.int32)

    def _task_success(self):
        if self.water_pos is None:
            return False
        agent_xy = np.asarray(self.unwrapped.agent_pos, dtype=np.int32)
        return manhattan(agent_xy, self.water_pos) <= self.success_radius

    def reset(self, **kwargs):
        obs, info = self.env.reset(**kwargs)
        self._install_water_marker()
        if hasattr(self.unwrapped, "gen_obs"):
            obs = self.unwrapped.gen_obs()
        info = dict(info or {})
        info["task_mode"] = "water_search_v1"
        info["task_mission"] = "find the water source"
        info["water_pos"] = None if self.water_pos is None else [int(v) for v in self.water_pos]
        info["water_task_success"] = 0
        return obs, info

    def step(self, action):
        obs, reward, terminated, truncated, info = self.env.step(action)
        info = dict(info or {})
        task_success = int(self._task_success())
        if task_success:
            reward = max(float(reward), self.success_reward)
            terminated = True
        else:
            reward = 0.0
        info["task_mode"] = "water_search_v1"
        info["task_mission"] = "find the water source"
        info["water_pos"] = None if self.water_pos is None else [int(v) for v in self.water_pos]
        info["water_task_success"] = int(task_success)
        if self.water_pos is not None:
            info["water_distance"] = int(manhattan(np.asarray(self.unwrapped.agent_pos, dtype=np.int32), self.water_pos))
        return obs, float(reward), bool(terminated), bool(truncated), info


class RestTaskWrapper(gym.Wrapper):
    def __init__(self, env, success_radius: int = 1, success_reward: float = 1.0):
        super().__init__(env)
        self.success_radius = max(1, int(success_radius))
        self.success_reward = float(success_reward)
        self.rest_pos = None

    def _find_cells(self, cell_type: str):
        cells = []
        grid = self.unwrapped.grid
        for y in range(grid.height):
            for x in range(grid.width):
                cell = grid.get(x, y)
                if cell is not None and cell.type == cell_type:
                    cells.append((int(x), int(y)))
        return cells

    def _fallback_rest_position(self):
        grid = self.unwrapped.grid
        agent_xy = tuple(int(v) for v in self.unwrapped.agent_pos)
        candidates = []
        for y in range(1, grid.height - 1):
            for x in range(1, grid.width - 1):
                if (x, y) == agent_xy:
                    continue
                cell = grid.get(x, y)
                if cell is None:
                    dist = abs(x - agent_xy[0]) + abs(y - agent_xy[1])
                    candidates.append((dist, y, x))
        if not candidates:
            return None
        candidates.sort(key=lambda item: (-item[0], item[1], item[2]))
        return int(candidates[0][2]), int(candidates[0][1])

    def _install_rest_marker(self):
        grid = self.unwrapped.grid
        goal_cells = self._find_cells("goal")
        for gx, gy in goal_cells:
            grid.set(int(gx), int(gy), None)
        if goal_cells:
            rx, ry = goal_cells[0]
        else:
            fallback = self._fallback_rest_position()
            if fallback is None:
                self.rest_pos = None
                return
            rx, ry = fallback
        grid.set(int(rx), int(ry), Box(color="green"))
        self.rest_pos = np.array([int(rx), int(ry)], dtype=np.int32)

    def _task_success(self):
        if self.rest_pos is None:
            return False
        agent_xy = np.asarray(self.unwrapped.agent_pos, dtype=np.int32)
        return manhattan(agent_xy, self.rest_pos) <= self.success_radius

    def reset(self, **kwargs):
        obs, info = self.env.reset(**kwargs)
        self._install_rest_marker()
        if hasattr(self.unwrapped, "gen_obs"):
            obs = self.unwrapped.gen_obs()
        info = dict(info or {})
        info["task_mode"] = "rest_search_v1"
        info["task_mission"] = "find a safe rest zone"
        info["rest_pos"] = None if self.rest_pos is None else [int(v) for v in self.rest_pos]
        info["rest_task_success"] = 0
        return obs, info

    def step(self, action):
        obs, reward, terminated, truncated, info = self.env.step(action)
        info = dict(info or {})
        task_success = int(self._task_success())
        if task_success:
            reward = max(float(reward), self.success_reward)
            terminated = True
        else:
            reward = 0.0
        info["task_mode"] = "rest_search_v1"
        info["task_mission"] = "find a safe rest zone"
        info["rest_pos"] = None if self.rest_pos is None else [int(v) for v in self.rest_pos]
        info["rest_task_success"] = int(task_success)
        if self.rest_pos is not None:
            info["rest_distance"] = int(manhattan(np.asarray(self.unwrapped.agent_pos, dtype=np.int32), self.rest_pos))
        return obs, float(reward), bool(terminated), bool(truncated), info


class BabyAISemanticWrapper(gym.Wrapper):
    def __init__(self, env):
        super().__init__(env)
        self.current_mission = ""
        self.current_intent = "find_goal_region"
        self.semantic_target_type = None
        self.semantic_target_color = None
        self.semantic_target_pos = None

    def _parse_mission(self, mission: str):
        mission_text = str(mission or "").strip().lower()
        mission_text = re.sub(r"\s+", " ", mission_text)
        direct_intent = BABYAI_INTENT_MAP.get(mission_text)
        object_color = None
        object_type = None
        match = re.match(r"go to the ([a-z]+) ([a-z]+)", mission_text)
        if match:
            object_color = str(match.group(1))
            object_type = str(match.group(2))
        elif mission_text.startswith("go to the "):
            tail = mission_text.replace("go to the ", "", 1).strip().split()
            if len(tail) == 1:
                object_type = str(tail[0])
            elif len(tail) >= 2:
                object_color = str(tail[0])
                object_type = str(tail[1])
        if direct_intent is not None:
            intent_name = direct_intent
        elif object_type is not None:
            intent_name = BABYAI_OBJECT_TYPE_TO_INTENT.get(object_type, "find_goal_region")
        else:
            intent_name = "find_goal_region"
        return {
            "mission": mission_text,
            "intent_name": str(intent_name),
            "object_type": object_type,
            "object_color": object_color,
        }

    def _match_target_cell(self, cell):
        if cell is None:
            return False
        if self.semantic_target_type is not None and str(getattr(cell, "type", "")) != str(self.semantic_target_type):
            return False
        cell_color = getattr(cell, "color", None)
        if self.semantic_target_color is not None and str(cell_color) != str(self.semantic_target_color):
            return False
        return True

    def _resolve_target_position(self):
        grid = self.unwrapped.grid
        candidates = []
        agent_xy = np.asarray(self.unwrapped.agent_pos, dtype=np.int32)
        for y in range(grid.height):
            for x in range(grid.width):
                cell = grid.get(x, y)
                if not self._match_target_cell(cell):
                    continue
                dist = manhattan(agent_xy, (x, y))
                candidates.append((dist, int(y), int(x)))
        if not candidates:
            self.semantic_target_pos = None
            return
        candidates.sort()
        _, y, x = candidates[0]
        self.semantic_target_pos = np.asarray([int(x), int(y)], dtype=np.int32)

    def _augment_info(self, info):
        info = dict(info or {})
        info["task_mode"] = "babyai_semantic_v1"
        info["task_mission"] = str(self.current_mission)
        info["episode_intent_type"] = str(self.current_intent)
        info["semantic_target_type"] = self.semantic_target_type
        info["semantic_target_color"] = self.semantic_target_color
        info["semantic_target_pos"] = (
            None if self.semantic_target_pos is None else [int(v) for v in self.semantic_target_pos]
        )
        return info

    def reset(self, **kwargs):
        obs, info = self.env.reset(**kwargs)
        mission = None
        if isinstance(obs, dict):
            mission = obs.get("mission")
        if mission is None:
            mission = dict(info or {}).get("mission", "")
        parsed = self._parse_mission(str(mission or ""))
        self.current_mission = parsed["mission"]
        self.current_intent = parsed["intent_name"]
        self.semantic_target_type = parsed["object_type"]
        self.semantic_target_color = parsed["object_color"]
        self._resolve_target_position()
        return obs, self._augment_info(info)

    def step(self, action):
        obs, reward, terminated, truncated, info = self.env.step(action)
        self._resolve_target_position()
        return obs, float(reward), bool(terminated), bool(truncated), self._augment_info(info)


def build_env(args):
    env = gym.make(args.env_id, render_mode="rgb_array")
    if str(getattr(args, "env_id", "")).startswith("BabyAI-"):
        env = BabyAISemanticWrapper(env)
    if getattr(args, "task_mode", "default") == "water_search_v1":
        env = WaterTaskWrapper(
            env,
            success_radius=int(getattr(args, "water_success_radius", 1)),
            success_reward=1.0,
        )
    elif getattr(args, "task_mode", "default") == "rest_search_v1":
        env = RestTaskWrapper(
            env,
            success_radius=int(getattr(args, "rest_success_radius", 1)),
            success_reward=1.0,
        )
    return env


def apply_goal_shift_v1(env, change_phase: int) -> bool:
    unwrapped = env.unwrapped
    grid = unwrapped.grid
    agent_xy = tuple(int(v) for v in unwrapped.agent_pos)
    current_goal = None
    candidates = []

    for y in range(grid.height):
        for x in range(grid.width):
            cell = grid.get(x, y)
            if cell is not None and cell.type == "goal":
                current_goal = (x, y)
            if (x, y) == agent_xy:
                continue
            if cell is None or (cell is not None and cell.type == "goal"):
                dist = abs(x - agent_xy[0]) + abs(y - agent_xy[1])
                candidates.append((dist, y, x))

    if len(candidates) < 2:
        return False

    candidates.sort(key=lambda item: (-item[0], item[1], item[2]))
    target_rank = min(len(candidates) - 1, int(change_phase % 2))
    tx = int(candidates[target_rank][2])
    ty = int(candidates[target_rank][1])
    target = (tx, ty)
    if current_goal == target:
        alt_rank = min(len(candidates) - 1, target_rank + 1)
        tx = int(candidates[alt_rank][2])
        ty = int(candidates[alt_rank][1])
        target = (tx, ty)

    if current_goal is not None and current_goal != target:
        grid.set(int(current_goal[0]), int(current_goal[1]), None)
    grid.set(tx, ty, Goal())
    return True


def apply_env_change(env, episode_idx: int, env_change_mode: str, change_after_episode: int) -> bool:
    if env_change_mode == "none":
        return False
    if int(change_after_episode) < 0 or int(episode_idx) < int(change_after_episode):
        return False
    if env_change_mode == "goal_shift_v1":
        return apply_goal_shift_v1(env, change_phase=int(episode_idx - change_after_episode))
    raise ValueError(f"Unknown env_change_mode: {env_change_mode}")


def safe_rate(numerator, denominator):
    if denominator == 0:
        return 0.0
    return float(numerator) / float(denominator)


def scene_risk_proxy(scene):
    if scene is None:
        return None
    risk = scene.risk_features
    return float(
        max(
            float(risk.get("collision_risk", 0.0)),
            float(risk.get("hazard_front", 0.0)),
            0.5 * float(risk.get("hazard_near", 0.0)),
            float(risk.get("lateral_hazard", 0.0)),
        )
    )


def scene_comfort_proxy(scene):
    if scene is None:
        return None
    alignment = float(scene.route_context.goal_alignment)
    return float(max(0.0, 1.0 - alignment))


def get_phrase_length_mean(memory):
    if memory is None or not memory.nodes:
        return 0.0
    lengths = [len(node["phrase"]) for node in memory.nodes.values()]
    if not lengths:
        return 0.0
    return float(np.mean(lengths))


def get_mean_xy(node, key_prefix):
    count = node.get(f"{key_prefix}_count", 0)
    if count <= 0:
        return None
    return node[f"{key_prefix}_sum"] / float(count)


def build_memory(args):
    tokenizer = None
    encoder = None
    if args.token_source == "symbolic_hash":
        tokenizer = SymbolicTokenizer(
            mode=args.tokenizer_mode,
            proj_dim=args.tokenizer_proj_dim,
            seed=args.seed,
        )
    elif args.token_source == "scene_semantic":
        encoder = MiniGridSceneEncoder(radius=args.scene_radius)
        tokenizer = SceneTokenizer(mode="semantic")
    elif args.token_source == "scene_patch_hash":
        encoder = MiniGridSceneEncoder(radius=args.scene_radius)
        tokenizer = SceneTokenizer(mode="patch_hash")
    else:
        raise ValueError(f"Unknown token_source: {args.token_source}")
    memory = DynamicSonglineGraph(
        min_goal_visits=args.min_goal_visits,
        graph_update_mode=args.graph_update_mode,
    )
    memory = SymbolicMemory(memory)
    planner = GraphRolloutPlanner()
    return tokenizer, encoder, memory, planner


def build_local_planner(args):
    return ManeuverSelector(), TrajectoryPlanner(commit_to_corridor=args.commit_to_corridor)


def build_episode_memory():
    return {
        "waypoints": {},
        "active_waypoint": None,
        "last_delta": None,
    }


def episodic_observe(ep_memory, pose_xy, distance_before, distance_after):
    if distance_before is None or distance_after is None:
        return
    improvement = float(distance_before - distance_after)
    key = (int(pose_xy[0]), int(pose_xy[1]))
    entry = ep_memory["waypoints"].get(key)
    if entry is None:
        ep_memory["waypoints"][key] = {
            "pos": np.asarray(pose_xy, dtype=np.int32),
            "score_sum": improvement,
            "score_count": 1,
            "last_improvement": improvement,
        }
    else:
        entry["score_sum"] += improvement
        entry["score_count"] += 1
        entry["last_improvement"] = improvement

    active = ep_memory["active_waypoint"]
    if active is not None and key == active["key"] and improvement <= 0:
        ep_memory["active_waypoint"] = None


def choose_episodic_waypoint(ep_memory):
    if not ep_memory["waypoints"]:
        return None

    scored = []
    for key, entry in ep_memory["waypoints"].items():
        mean_score = entry["score_sum"] / max(1, entry["score_count"])
        scored.append((mean_score, entry["score_count"], key))
    scored.sort(reverse=True)

    best_score, _, best_key = scored[0]
    if best_score <= 0:
        return None

    best_entry = ep_memory["waypoints"][best_key]
    ep_memory["active_waypoint"] = {
        "key": best_key,
        "pos": best_entry["pos"].copy(),
        "score": float(best_score),
    }
    return best_entry["pos"].copy()


def current_phrase_node(memory):
    if memory is None:
        return None
    return memory.current_phrase_id


def _cell_code(env, x, y):
    grid = env.unwrapped.grid
    if x < 0 or y < 0 or x >= grid.width or y >= grid.height:
        return 99
    cell = grid.get(x, y)
    if cell is None:
        return 0
    if cell.type == "wall":
        return 1
    if cell.type == "goal":
        return 2
    if cell.type == "lava":
        return 3
    if cell.type == "door":
        return 4
    return 8


def _dir_to_delta(agent_dir):
    return {
        0: (1, 0),
        1: (0, 1),
        2: (-1, 0),
        3: (0, -1),
    }[int(agent_dir)]


def _hazard_aware_waypoint(env, current_token_label, plan_waypoint_xy, goal_xy):
    if current_token_label not in {"hazard_front", "gap_search"}:
        return None

    unwrapped = env.unwrapped
    ax, ay = [int(v) for v in unwrapped.agent_pos]
    agent_dir = int(unwrapped.agent_dir)
    target_xy = goal_xy if goal_xy is not None else plan_waypoint_xy
    if target_xy is None:
        return None

    candidates = []
    for dir_idx in range(4):
        dx, dy = _dir_to_delta(dir_idx)
        nx, ny = ax + dx, ay + dy
        code = _cell_code(env, nx, ny)
        if code not in (0, 2):
            continue

        left_dir = (dir_idx - 1) % 4
        right_dir = (dir_idx + 1) % 4
        ldx, ldy = _dir_to_delta(left_dir)
        rdx, rdy = _dir_to_delta(right_dir)
        left_code = _cell_code(env, nx + ldx, ny + ldy)
        right_code = _cell_code(env, nx + rdx, ny + rdy)
        lateral_hazard = float(left_code == 3 or right_code == 3)
        lateral_blocked = float(left_code in (1, 3, 99) or right_code in (1, 3, 99))
        goal_dx = int(target_xy[0]) - nx
        goal_dy = int(target_xy[1]) - ny
        norm = float(max(1e-6, (goal_dx * goal_dx + goal_dy * goal_dy) ** 0.5))
        heading_alignment = ((dx * goal_dx) + (dy * goal_dy)) / norm
        goal_progress = -manhattan(np.array([nx, ny]), np.asarray(target_xy))
        score = (2.5 * heading_alignment) + (1.5 * lateral_hazard) + (0.75 * lateral_blocked) + (0.1 * goal_progress)
        candidates.append((score, np.array([nx, ny], dtype=np.int32)))

    if not candidates:
        return None
    candidates.sort(key=lambda item: item[0], reverse=True)
    return candidates[0][1]


def _target_waypoint_stats(env, source_xy, target_xy, goal_xy):
    if target_xy is None:
        return {
            "hazard_adjacent": 0,
            "goal_alignment": 0.0,
        }

    tx, ty = [int(v) for v in target_xy]
    hazard_adjacent = 0
    for dir_idx in range(4):
        dx, dy = _dir_to_delta(dir_idx)
        if _cell_code(env, tx + dx, ty + dy) == 3:
            hazard_adjacent = 1
            break

    goal_alignment = 0.0
    if source_xy is not None and goal_xy is not None:
        sx, sy = [int(v) for v in source_xy]
        gx, gy = [int(v) for v in goal_xy]
        tdx = tx - sx
        tdy = ty - sy
        gdx = gx - sx
        gdy = gy - sy
        target_norm = float(max(1e-6, (tdx * tdx + tdy * tdy) ** 0.5))
        goal_norm = float(max(1e-6, (gdx * gdx + gdy * gdy) ** 0.5))
        goal_alignment = float(((tdx * gdx) + (tdy * gdy)) / (target_norm * goal_norm))

    return {
        "hazard_adjacent": int(hazard_adjacent),
        "goal_alignment": float(goal_alignment),
    }


def _stable_goal_rejoin_waypoint(env, goal_xy, radius=2, avoid_hazard_adjacent=False, max_radius=None):
    if goal_xy is None:
        return None

    unwrapped = env.unwrapped
    ax, ay = [int(v) for v in unwrapped.agent_pos]
    current_xy = np.array([ax, ay], dtype=np.int32)
    goal_xy = np.asarray(goal_xy, dtype=np.int32)
    current_goal_distance = manhattan(current_xy, goal_xy)

    if max_radius is None:
        max_radius = radius

    best_safe = []
    best_any = []
    for current_radius in range(int(radius), int(max_radius) + 1):
        candidates = []
        for dx in range(-current_radius, current_radius + 1):
            for dy in range(-current_radius, current_radius + 1):
                if abs(dx) + abs(dy) == 0 or abs(dx) + abs(dy) > current_radius:
                    continue
                nx, ny = ax + dx, ay + dy
                code = _cell_code(env, nx, ny)
                if code not in (0, 2):
                    continue

                waypoint_xy = np.array([nx, ny], dtype=np.int32)
                goal_distance = manhattan(waypoint_xy, goal_xy)
                goal_progress = float(current_goal_distance - goal_distance)
                if goal_progress < 0.0:
                    continue

                free_neighbors = 0
                hazard_neighbors = 0
                for dir_idx in range(4):
                    ddx, ddy = _dir_to_delta(dir_idx)
                    ncode = _cell_code(env, nx + ddx, ny + ddy)
                    if ncode in (0, 2):
                        free_neighbors += 1
                    if ncode == 3:
                        hazard_neighbors += 1

                stats = _target_waypoint_stats(env, current_xy, waypoint_xy, goal_xy)
                score = (
                    2.0 * goal_progress
                    + 1.25 * stats["goal_alignment"]
                    + 0.35 * free_neighbors
                    - 1.5 * hazard_neighbors
                    - 0.15 * (abs(dx) + abs(dy))
                )
                candidates.append((score, waypoint_xy, stats))
                best_any.append((score, waypoint_xy, stats))

            if candidates:
                safe_candidates = [item for item in candidates if int(item[2]["hazard_adjacent"]) == 0]
                if safe_candidates:
                    best_safe.extend(safe_candidates)
                    if avoid_hazard_adjacent:
                        break

    if avoid_hazard_adjacent and best_safe:
        best_safe.sort(key=lambda item: item[0], reverse=True)
        return best_safe[0][1]
    if best_any:
        best_any.sort(key=lambda item: item[0], reverse=True)
        return best_any[0][1]
    return None


def select_graph_waypoint(
    memory,
    planner,
    selector,
    top_k,
    rollout_horizon,
    current_token_label=None,
    env=None,
    goal_xy=None,
    planner_query=None,
):
    if hasattr(memory, "query_paths"):
        plans = memory.query_paths(
            planner_query=planner_query,
            current_node_id=current_phrase_node(memory),
            planner=planner,
            horizon=rollout_horizon,
            top_k=top_k,
        )
    else:
        plans = planner.rollout(
            graph=memory,
            current_node_id=current_phrase_node(memory),
            horizon=rollout_horizon,
            top_k=top_k,
            planner_query=planner_query,
        )
    if not plans:
        return None

    plan = plans[0]
    command = selector.select(plan, current_token=current_token_label)
    if command.get("waypoint_xy") is None:
        return None

    waypoint_xy = np.asarray(command["waypoint_xy"], dtype=np.int32)
    hazard_waypoint = None
    if env is not None:
        hazard_waypoint = _hazard_aware_waypoint(
            env,
            current_token_label=current_token_label,
            plan_waypoint_xy=waypoint_xy,
            goal_xy=goal_xy,
        )
    if hazard_waypoint is not None:
        waypoint_xy = hazard_waypoint
        command["waypoint_xy"] = tuple(int(v) for v in waypoint_xy)
    if planner_query is not None and goal_xy is None and env is not None:
        current_xy = np.asarray(env.unwrapped.agent_pos, dtype=np.int32)
        if int(manhattan(current_xy, waypoint_xy)) == 0:
            return None
    planner_debug = dict(plan.metadata)
    if hasattr(memory, "last_concept_query_debug") and "concept_query_debug" not in planner_debug:
        planner_debug["concept_query_debug"] = dict(getattr(memory, "last_concept_query_debug", {}) or {})
        planner_debug["candidate_concept_membership"] = dict(
            planner_debug["concept_query_debug"].get("cluster_membership", {})
        )
    if plan.target_node_id is not None and plan.target_node_id in memory.nodes:
        planner_debug["selected_node_semantic_tag_confidence"] = dict(
            memory.nodes[plan.target_node_id].get("semantic_tag_confidence", {})
        )
    else:
        planner_debug["selected_node_semantic_tag_confidence"] = {}

    return {
        "waypoint_xy": waypoint_xy,
        "target_node_id": command.get("target_node_id"),
        "next_node_id": int(plan.metadata["next_node_id"]),
        "graph_path_length": int(command.get("graph_path_length", plan.graph_path_length)),
        "utility": float(plan.utility),
        "token_sequence": list(plan.token_sequence),
        "maneuver_command": command,
        "planner_debug": planner_debug,
    }


def select_semantic_waypoint_fallback(memory, planner_query, current_node_id=None, source_xy=None, top_k=5):
    if planner_query is None or memory is None or not hasattr(memory, "candidate_nodes_for_query"):
        return None
    candidate_ids = memory.candidate_nodes_for_query(
        planner_query,
        top_k=top_k,
        current_node_id=current_node_id,
    )
    if not candidate_ids:
        return None

    selected_node_id = None
    waypoint_xy = None
    source_arr = None if source_xy is None else np.asarray(source_xy, dtype=np.int32)
    for node_id in candidate_ids:
        node_id = int(node_id)
        if current_node_id is not None and int(node_id) == int(current_node_id):
            continue
        pose_xy = memory.get_mean_xy(node_id, "pose")
        if pose_xy is None:
            continue
        rounded_pose = np.rint(pose_xy).astype(np.int32)
        if source_arr is not None and int(manhattan(rounded_pose, source_arr)) == 0:
            continue
        selected_node_id = node_id
        waypoint_xy = rounded_pose
        break
    if selected_node_id is None or waypoint_xy is None:
        return None
    candidate_base_utilities = {}
    candidate_tag_confidences = {}
    candidate_intent_scores = {}
    query_tag_name = str(planner_query.target_predicate.tag_name)
    for node_id in candidate_ids:
        node_key = str(node_id)
        candidate_base_utilities[node_key] = float(memory.node_utility(node_id))
        candidate_tag_confidences[node_key] = float(
            memory.nodes[node_id].get("semantic_tag_confidence", {}).get(query_tag_name, 0.0)
        )
        candidate_intent_scores[node_key] = float(memory.node_intent_score(node_id, planner_query=planner_query))

    return {
        "waypoint_xy": np.asarray(waypoint_xy, dtype=np.int32).copy(),
        "target_node_id": selected_node_id,
        "next_node_id": selected_node_id,
        "graph_path_length": 0,
        "utility": float(candidate_intent_scores[str(selected_node_id)]),
        "token_sequence": [],
        "maneuver_command": {
            "command_type": "go_to_waypoint",
            "waypoint_xy": tuple(int(v) for v in waypoint_xy),
        },
        "planner_debug": {
            "next_node_id": int(selected_node_id),
            "intent_type": str(planner_query.intent_type.value),
            "query_tag_name": query_tag_name,
            "used_intent_query": True,
            "candidate_node_ids": [int(cid) for cid in candidate_ids],
            "candidate_base_utilities": candidate_base_utilities,
            "candidate_tag_confidences": candidate_tag_confidences,
            "candidate_intent_scores": candidate_intent_scores,
            "candidate_concept_membership": dict(
                getattr(memory, "last_concept_query_debug", {}).get("cluster_membership", {})
            ),
            "concept_query_debug": dict(getattr(memory, "last_concept_query_debug", {}) or {}),
            "selected_tag_confidence": float(candidate_tag_confidences.get(str(selected_node_id), 0.0)),
            "selected_intent_score": float(candidate_intent_scores.get(str(selected_node_id), 0.0)),
            "selected_plan_utility": float(candidate_intent_scores.get(str(selected_node_id), 0.0)),
            "selected_node_semantic_tag_confidence": dict(
                memory.nodes[selected_node_id].get("semantic_tag_confidence", {})
            ),
            "plan_source": "semantic_pose_fallback",
        },
    }


def make_method_name(agent_mode, songline_policy):
    if agent_mode == "songline":
        return f"songline_{songline_policy}"
    return agent_mode


def apply_milestone_mode(args):
    if getattr(args, "milestone_mode", "none") == "semantic_handoff_v1":
        args.agent_mode = "songline"
        args.songline_policy = "graph_path"
        args.token_source = "scene_semantic"
        args.early_hazard_intervention = True
    return args


def parse_intent_type(name: str) -> IntentType:
    return IntentType(name)


def effective_intent_type_name(args) -> str:
    override = getattr(args, "episode_intent_type_override", None)
    if override not in (None, ""):
        return str(override)
    return str(getattr(args, "intent_type", IntentType.FIND_GOAL_REGION.value))


def is_defensive_intent(intent_type: IntentType) -> bool:
    return intent_type in {
        IntentType.REACH_SAFE_EXIT,
        IntentType.HAZARD_RECOVERY_EXIT,
    }


def should_use_post_recovery_goal_handoff(args) -> bool:
    return getattr(args, "intent_handoff_mode", "none") == "post_recovery_goal_v1"


def should_use_goal_rejoin_guard(args) -> bool:
    return getattr(args, "goal_rejoin_guard_mode", "none") == "debounce_v1"


def should_use_goal_rejoin_target_fallback(args) -> bool:
    return goal_rejoin_fallback_assists_enabled(args) and getattr(args, "goal_rejoin_target_mode", "none") == "fallback_goal_v1"


def should_use_stable_goal_rejoin_waypoint(args) -> bool:
    return goal_rejoin_fallback_assists_enabled(args) and getattr(args, "goal_rejoin_target_mode", "none") == "stable_waypoint_v1"


def should_use_source_selected_goal_rejoin(args) -> bool:
    return goal_rejoin_fallback_assists_enabled(args) and getattr(args, "goal_rejoin_target_mode", "none") in {"source_select_v1", "source_select_v2"}


def should_use_strict_stable_goal_rejoin(args) -> bool:
    return goal_rejoin_fallback_assists_enabled(args) and getattr(args, "goal_rejoin_target_mode", "none") == "source_select_v2"


def _select_rejoin_target_source(args, env, source_xy, goal_xy, graph_waypoint_xy, planner_debug):
    graph_waypoint = None if graph_waypoint_xy is None else np.asarray(graph_waypoint_xy, dtype=np.int32).copy()
    graph_stats = _target_waypoint_stats(env, source_xy, graph_waypoint, goal_xy) if graph_waypoint is not None else {
        "hazard_adjacent": 0,
        "goal_alignment": 0.0,
    }
    selected_conf = {} if planner_debug is None else dict(planner_debug.get("selected_node_semantic_tag_confidence", {}))
    goal_region_conf = float(selected_conf.get("goal_region", 0.0))

    decision = {
        "selected_source": "none",
        "selected_waypoint_xy": None,
        "graph_node_considered": int(graph_waypoint is not None),
        "graph_node_goal_region_confidence": goal_region_conf,
        "graph_node_hazard_adjacent": int(graph_stats["hazard_adjacent"]),
        "graph_node_goal_alignment": float(graph_stats["goal_alignment"]),
        "graph_node_accepted": 0,
        "graph_node_rejected": 0,
        "graph_node_reject_reason": "none",
        "stable_waypoint_available": 0,
    }

    if should_use_source_selected_goal_rejoin(args):
        stable_waypoint = _stable_goal_rejoin_waypoint(
            env,
            goal_xy,
            avoid_hazard_adjacent=should_use_strict_stable_goal_rejoin(args),
            max_radius=4 if should_use_strict_stable_goal_rejoin(args) else 2,
        )
        decision["stable_waypoint_available"] = int(stable_waypoint is not None)
        graph_ok = bool(
            graph_waypoint is not None
            and goal_region_conf >= 0.5
            and int(graph_stats["hazard_adjacent"]) == 0
        )
        if graph_ok:
            decision["selected_source"] = "graph_node"
            decision["selected_waypoint_xy"] = graph_waypoint
            decision["graph_node_accepted"] = 1
            return decision
        if graph_waypoint is not None:
            decision["graph_node_rejected"] = 1
            if goal_region_conf < 0.5:
                decision["graph_node_reject_reason"] = "low_goal_region_confidence"
            elif int(graph_stats["hazard_adjacent"]) != 0:
                decision["graph_node_reject_reason"] = "hazard_adjacent"
            else:
                decision["graph_node_reject_reason"] = "source_select_guard"
        if stable_waypoint is not None:
            decision["selected_source"] = "stable_rejoin_waypoint"
            decision["selected_waypoint_xy"] = np.asarray(stable_waypoint, dtype=np.int32).copy()
            return decision
        if graph_waypoint is not None:
            decision["selected_source"] = "graph_node"
            decision["selected_waypoint_xy"] = graph_waypoint
            return decision
        return decision

    if graph_waypoint is not None:
        decision["selected_source"] = "graph_node"
        decision["selected_waypoint_xy"] = graph_waypoint
        decision["graph_node_accepted"] = 1
        return decision

    return decision


def resolve_active_intent_type(args, agent_state=None, intent_policy=None, scene=None):
    if getattr(args, "intent_mode", "none") == "none":
        return None, "intent_mode_none"
    if getattr(args, "intent_selection_mode", "fixed") == "state_v1":
        if agent_state is None or intent_policy is None:
            return parse_intent_type(effective_intent_type_name(args)), "state_policy_missing_fallback"
        if hasattr(intent_policy, "select_intent_with_reason"):
            return intent_policy.select_intent_with_reason(agent_state, scene=scene)
        return intent_policy.select_intent(agent_state, scene=scene), "state_policy"
    return parse_intent_type(effective_intent_type_name(args)), "fixed_intent"


def current_planner_query(args, goal_xy=None, active_intent_type=None, agent_state=None):
    if getattr(args, "intent_mode", "none") == "none":
        return None
    if active_intent_type is None:
        active_intent_type = parse_intent_type(effective_intent_type_name(args))
    planner_query = build_planner_query(active_intent_type, goal_xy=goal_xy)
    retrieval_mode = str(getattr(args, "semantic_retrieval_mode", "concept_recall_v1"))
    if retrieval_mode == "node_only":
        planner_query.target_predicate.metadata["use_concept_recall"] = False
        planner_query.target_predicate.metadata["use_concept_planning"] = False
        planner_query.metadata["use_concept_recall"] = False
        planner_query.metadata["use_concept_planning"] = False
    elif retrieval_mode == "concept_plan_v1":
        planner_query.target_predicate.metadata["use_concept_recall"] = True
        planner_query.target_predicate.metadata["use_concept_planning"] = True
        planner_query.metadata["use_concept_recall"] = True
        planner_query.metadata["use_concept_planning"] = True
    else:
        planner_query.target_predicate.metadata["use_concept_recall"] = True
        planner_query.target_predicate.metadata["use_concept_planning"] = False
        planner_query.metadata["use_concept_recall"] = True
        planner_query.metadata["use_concept_planning"] = False
    planner_query.metadata["semantic_retrieval_mode"] = retrieval_mode
    if agent_state is not None:
        planner_query.metadata["agent_state_snapshot"] = {
            "thirst": float(getattr(agent_state, "thirst", 0.0)),
            "energy": float(getattr(agent_state, "energy", 0.0)),
            "risk_budget": float(getattr(agent_state, "risk_budget", 0.0)),
            "task_phase": str(getattr(agent_state, "task_phase", "")),
            "previous_task_phase": str(getattr(agent_state, "previous_task_phase", "")),
        }
    return planner_query


def export_run_summary(out_dir, run_summary):
    with open(os.path.join(out_dir, "run_summary.json"), "w") as f:
        json.dump(run_summary, f, indent=2)

    episodes = np.arange(1, len(run_summary["episode_returns"]) + 1)
    if len(episodes) == 0:
        return

    plt.figure(figsize=(6, 4))
    plt.plot(episodes, run_summary["episode_returns"])
    plt.xlabel("Episode")
    plt.ylabel("Return")
    plt.title("Episode Returns")
    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, "episode_returns.png"))
    plt.close()

    plt.figure(figsize=(6, 4))
    plt.plot(episodes, run_summary["episode_lengths"])
    plt.xlabel("Episode")
    plt.ylabel("Steps")
    plt.title("Episode Lengths")
    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, "episode_lengths.png"))
    plt.close()

    plt.figure(figsize=(6, 4))
    plt.plot(episodes, run_summary["graph_nodes"])
    plt.plot(episodes, run_summary["graph_edges"])
    plt.xlabel("Episode")
    plt.ylabel("Count")
    plt.title("Graph Growth by Episode")
    plt.legend(["nodes", "edges"])
    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, "graph_growth_by_episode.png"))
    plt.close()


def export_debug_trace(out_dir, trace_rows):
    if not trace_rows:
        return
    trace_dir = os.path.join(out_dir, "traces")
    ensure_dir(trace_dir)

    json_path = os.path.join(trace_dir, "step_trace.json")
    with open(json_path, "w") as f:
        json.dump(trace_rows, f, indent=2)

    csv_path = os.path.join(trace_dir, "step_trace.csv")
    fieldnames = list(trace_rows[0].keys())
    with open(csv_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in trace_rows:
            writer.writerow(row)


def _demo_caption_lines(meta):
    event = meta.get("event", "")
    line1 = f"ep {meta.get('episode', '?')} step {meta.get('step', '?')} token={meta.get('token', '?')} action={meta.get('action', '?')}"
    line2 = (
        f"intent={meta.get('intent', 'none')} src={meta.get('rejoin_source', 'none')} "
        f"haz_adj={meta.get('hazard_adjacent', 0)} align={meta.get('goal_alignment', 0.0):.2f}"
    )
    line3 = (
        f"pos={meta.get('pos', '?')} subgoal={meta.get('subgoal', None)} "
        f"dist={meta.get('distance_after', '?')} reward={meta.get('reward', 0.0):.3f}"
    )
    if event:
        line3 = f"{line3} | {event}"
    return [line1, line2, line3]


def _annotate_demo_frame(frame, meta):
    import numpy as np
    from PIL import Image, ImageDraw

    lines = _demo_caption_lines(meta)
    image = Image.fromarray(np.asarray(frame, dtype=np.uint8))
    width, height = image.size
    footer_h = 22 * len(lines) + 12
    canvas = Image.new("RGB", (width, height + footer_h), (12, 12, 12))
    canvas.paste(image, (0, 0))
    draw = ImageDraw.Draw(canvas)
    y = height + 6
    for line in lines:
        draw.text((8, y), str(line), fill=(245, 245, 245))
        y += 22
    return np.asarray(canvas, dtype=np.uint8)


def export_demo_artifacts(out_dir, frames, frame_meta, fps=3):
    if not frames or not frame_meta or len(frames) != len(frame_meta):
        return

    try:
        import imageio.v2 as imageio
    except Exception:
        import imageio
    import numpy as np
    from PIL import Image

    demo_dir = os.path.join(out_dir, "demo")
    ensure_dir(demo_dir)

    annotated = [_annotate_demo_frame(frame, meta) for frame, meta in zip(frames, frame_meta)]

    gif_path = os.path.join(demo_dir, "demo.gif")
    imageio.mimsave(gif_path, annotated, duration=max(0.05, 1.0 / max(1, int(fps))))

    json_path = os.path.join(demo_dir, "demo_metadata.json")
    with open(json_path, "w") as f:
        json.dump(frame_meta, f, indent=2)

    key_count = min(6, len(annotated))
    indices = np.linspace(0, len(annotated) - 1, num=key_count, dtype=int)
    unique_indices = []
    seen = set()
    for idx in indices:
        if int(idx) not in seen:
            unique_indices.append(int(idx))
            seen.add(int(idx))
    tiles = [Image.fromarray(annotated[idx]) for idx in unique_indices]
    tile_w = max(tile.width for tile in tiles)
    tile_h = max(tile.height for tile in tiles)
    sheet = Image.new("RGB", (tile_w * len(tiles), tile_h), (255, 255, 255))
    for i, tile in enumerate(tiles):
        sheet.paste(tile, (i * tile_w, 0))
    sheet.save(os.path.join(demo_dir, "storyboard.png"))


def is_hazard_phase_token(token_label):
    return token_label in {"hazard_front", "gap_search", "gap_aligned", "safe_crossing"}


def should_run_graph_intervention(args, step, token_label, active_subgoal_key, hazard_phase_intervened):
    scheduled = (step % args.suggest_every == 0)
    if args.songline_policy != "graph_path":
        return scheduled
    if not args.early_hazard_intervention:
        return scheduled
    hazard_trigger = is_hazard_phase_token(token_label) and active_subgoal_key is None and not hazard_phase_intervened
    return scheduled or hazard_trigger


def should_activate_hazard_commit(scene, hazard_phase_active, subgoal_xy):
    if not hazard_phase_active or scene is None or subgoal_xy is None:
        return False
    risk = scene.risk_features
    front_safe = int(risk.get("front_safe", 0.0)) == 1
    goal_alignment = float(risk.get("goal_heading_alignment", 0.0))
    return bool(front_safe and goal_alignment >= 0.35)


def clear_active_graph_plan():
    return {
        "subgoal_xy": None,
        "active_subgoal_key": None,
        "active_graph_path_length": 0,
        "active_target_node_id": None,
        "active_next_node_id": None,
        "active_maneuver_command": None,
        "active_maneuver_command_type": None,
        "active_planner_debug": None,
    }


def goal_rejoin_fallback_assists_enabled(args) -> bool:
    return not bool(getattr(args, "disable_goal_rejoin_fallback_assists", False))


def local_resource_guidance_enabled(args) -> bool:
    return not bool(getattr(args, "disable_local_resource_guidance", False))


def _episode_query_records(memory, episode_id: int):
    if memory is None or not hasattr(memory, "query_debug_records"):
        return []
    return [
        record
        for record in getattr(memory, "query_debug_records", [])
        if int(getattr(record, "episode_id", -1)) == int(episode_id)
    ]


def compute_episode_query_metrics(memory, episode_id: int, success: int):
    records = _episode_query_records(memory, episode_id=episode_id)
    attempts = int(len(records))
    if attempts <= 0:
        return {
            "query_attempt_count": 0,
            "query_nonempty_rate": 0.0,
            "retrieval_precision_at_k": 0.0,
            "query_satisfaction_rate": 0.0,
            "semantic_target_materialization_rate": 0.0,
            "semantic_target_materialized_any": 0,
            "post_retrieval_completion": 0,
            "completion_given_materialized": 0.0,
            "no_retrieval_attempt": 1,
            "retrieval_failure_empty": 0,
            "retrieval_failure_unsatisfied": 0,
            "semantic_materialization_failure": 0,
            "control_failure_after_retrieval": 0,
            "failure_taxonomy": "no_retrieval_attempt",
        }
    nonempty = float(sum(1 for record in records if list(getattr(record, "candidate_node_ids", []))))
    retrieval_precision_vals = [
        float(getattr(record, "metadata", {}).get("retrieval_precision_at_k", 0.0))
        for record in records
    ]
    satisfied = float(
        sum(int(getattr(record, "metadata", {}).get("selected_query_satisfied", 0)) for record in records)
    )
    materialized = float(
        sum(int(getattr(record, "metadata", {}).get("semantic_target_materialized", 0)) for record in records)
    )
    materialized_any = int(materialized > 0.0)
    post_retrieval_completion = int(materialized_any and int(success) > 0)
    query_nonempty_rate = float(nonempty / max(1, attempts))
    retrieval_precision_at_k = float(np.mean(retrieval_precision_vals)) if retrieval_precision_vals else 0.0
    query_satisfaction_rate = float(satisfied / max(1, attempts))
    semantic_target_materialization_rate = float(materialized / max(1, attempts))
    completion_given_materialized = float(post_retrieval_completion / max(1, materialized_any))

    if int(success) > 0:
        taxonomy = "success"
    elif nonempty <= 0.0:
        taxonomy = "retrieval_failure_empty"
    elif satisfied <= 0.0:
        taxonomy = "retrieval_failure_unsatisfied"
    elif materialized <= 0.0:
        taxonomy = "semantic_materialization_failure"
    else:
        taxonomy = "control_failure_after_retrieval"

    return {
        "query_attempt_count": int(attempts),
        "query_nonempty_rate": float(query_nonempty_rate),
        "retrieval_precision_at_k": float(retrieval_precision_at_k),
        "query_satisfaction_rate": float(query_satisfaction_rate),
        "semantic_target_materialization_rate": float(semantic_target_materialization_rate),
        "semantic_target_materialized_any": int(materialized_any),
        "post_retrieval_completion": int(post_retrieval_completion),
        "completion_given_materialized": float(completion_given_materialized),
        "no_retrieval_attempt": int(attempts <= 0),
        "retrieval_failure_empty": int(taxonomy == "retrieval_failure_empty"),
        "retrieval_failure_unsatisfied": int(taxonomy == "retrieval_failure_unsatisfied"),
        "semantic_materialization_failure": int(taxonomy == "semantic_materialization_failure"),
        "control_failure_after_retrieval": int(taxonomy == "control_failure_after_retrieval"),
        "failure_taxonomy": taxonomy,
    }


def summarise_run(run_summary, memory):
    final_nodes = 0 if memory is None else int(len(memory.nodes))
    final_edges = 0 if memory is None else int(sum(len(v) for v in memory.edges.values()))
    intervention_rate = 0.0
    plan_hit_rate = 0.0
    phrase_length_mean = 0.0
    overall_success = float(np.mean(run_summary["successes"])) if run_summary["successes"] else 0.0
    num_pre_change_episodes = int(len(run_summary["successes_pre_change"]))
    num_post_change_episodes = int(len(run_summary["successes_post_change"]))
    change_split_active = bool(
        run_summary.get("env_change_mode", "none") != "none"
        and num_pre_change_episodes > 0
        and num_post_change_episodes > 0
    )
    if change_split_active:
        pre_change_success = float(np.mean(run_summary["successes_pre_change"]))
        post_change_success = float(np.mean(run_summary["successes_post_change"]))
        change_eval_mode = "nonstationary_split"
    else:
        pre_change_success = overall_success
        post_change_success = overall_success
        change_eval_mode = "stationary_equivalent"

    if memory is not None:
        intervention_rate = safe_rate(memory.interventions, memory.intervention_attempts)
        plan_hit_rate = safe_rate(memory.plan_hits, memory.plan_total)
        phrase_length_mean = get_phrase_length_mean(memory)

    summary = {
        "success_rate": overall_success,
        "success_rate_pre_change": pre_change_success,
        "success_rate_post_change": post_change_success,
        "success_rate_change_delta": post_change_success - pre_change_success,
        "num_pre_change_episodes": num_pre_change_episodes,
        "num_post_change_episodes": num_post_change_episodes,
        "change_split_active": int(change_split_active),
        "change_eval_mode": change_eval_mode,
        "avg_return": float(np.mean(run_summary["episode_returns"])) if run_summary["episode_returns"] else 0.0,
        "avg_steps_to_goal": float(np.mean(run_summary["episode_lengths"])) if run_summary["episode_lengths"] else 0.0,
        "avg_steps": float(np.mean(run_summary["episode_lengths"])) if run_summary["episode_lengths"] else 0.0,
        "intervention_rate": intervention_rate,
        "plan_hit_rate": plan_hit_rate,
        "graph_nodes": final_nodes,
        "graph_edges": final_edges,
        "phrase_length_mean": phrase_length_mean,
        "subgoal_reach_rate": safe_rate(
            float(np.sum(run_summary["subgoal_reached"])),
            len(run_summary["subgoal_reached"]),
        ),
        "goal_distance_delta_per_intervention": safe_rate(
            float(np.sum(run_summary["goal_distance_delta_per_intervention"])),
            max(1, len(run_summary["goal_distance_delta_per_intervention"])),
        ),
        "node_reuse_rate": safe_rate(
            float(np.sum(run_summary["node_reuse_rate"])),
            len(run_summary["node_reuse_rate"]),
        ),
        "new_nodes_per_episode": float(np.mean(run_summary["new_nodes_per_episode"])) if run_summary["new_nodes_per_episode"] else 0.0,
        "graph_path_length": float(np.mean(run_summary["graph_path_length"])) if run_summary["graph_path_length"] else 0.0,
        "fraction_gap_aligned": float(np.mean(run_summary["has_gap_aligned"])) if run_summary["has_gap_aligned"] else 0.0,
        "fraction_safe_crossing": float(np.mean(run_summary["has_safe_crossing"])) if run_summary["has_safe_crossing"] else 0.0,
        "fraction_post_hazard": float(np.mean(run_summary["has_post_hazard"])) if run_summary["has_post_hazard"] else 0.0,
        "fraction_final_exit_maneuver": float(np.mean(run_summary["has_final_exit_maneuver"])) if run_summary["has_final_exit_maneuver"] else 0.0,
        "fraction_resume_to_goal": float(np.mean(run_summary["has_resume_to_goal"])) if run_summary["has_resume_to_goal"] else 0.0,
        "fraction_post_hazard_progress": float(np.mean(run_summary["has_post_hazard_progress"])) if run_summary["has_post_hazard_progress"] else 0.0,
        "fraction_resume_to_goal_progress": float(np.mean(run_summary["has_resume_to_goal_progress"])) if run_summary["has_resume_to_goal_progress"] else 0.0,
        "fraction_post_hazard_to_success": float(np.mean(run_summary["post_hazard_to_success"])) if run_summary["post_hazard_to_success"] else 0.0,
        "fraction_resume_to_goal_to_success": float(np.mean(run_summary["resume_to_goal_to_success"])) if run_summary["resume_to_goal_to_success"] else 0.0,
        "conditional_post_hazard_success": safe_rate(
            float(np.sum(run_summary["post_hazard_to_success"])),
            float(np.sum(run_summary["has_post_hazard"])),
        ),
        "conditional_resume_to_goal_success": safe_rate(
            float(np.sum(run_summary["resume_to_goal_to_success"])),
            float(np.sum(run_summary["has_resume_to_goal"])),
        ),
        "mean_max_phase_depth": float(np.mean(run_summary["max_phase_depth"])) if run_summary["max_phase_depth"] else 0.0,
        "query_attempt_count": float(np.mean(run_summary["query_attempt_count"])) if run_summary["query_attempt_count"] else 0.0,
        "query_nonempty_rate": float(np.mean(run_summary["query_nonempty_rate"])) if run_summary["query_nonempty_rate"] else 0.0,
        "retrieval_precision_at_k": float(np.mean(run_summary["retrieval_precision_at_k"])) if run_summary["retrieval_precision_at_k"] else 0.0,
        "query_satisfaction_rate": float(np.mean(run_summary["query_satisfaction_rate"])) if run_summary["query_satisfaction_rate"] else 0.0,
        "semantic_target_materialization_rate": float(np.mean(run_summary["semantic_target_materialization_rate"])) if run_summary["semantic_target_materialization_rate"] else 0.0,
        "post_retrieval_completion_rate": float(np.mean(run_summary["post_retrieval_completion"])) if run_summary["post_retrieval_completion"] else 0.0,
        "completion_given_materialized": safe_rate(
            float(np.sum(run_summary["post_retrieval_completion"])),
            float(np.sum(run_summary["semantic_target_materialized_any"])),
        ),
        "local_resource_guidance_usage_rate": float(np.mean(run_summary["local_resource_guidance_used"])) if run_summary["local_resource_guidance_used"] else 0.0,
        "goal_rejoin_fallback_assist_usage_rate": float(np.mean(run_summary["goal_rejoin_fallback_assist_used"])) if run_summary["goal_rejoin_fallback_assist_used"] else 0.0,
        "retrieval_failure_empty_rate": float(np.mean(run_summary["retrieval_failure_empty"])) if run_summary["retrieval_failure_empty"] else 0.0,
        "retrieval_failure_unsatisfied_rate": float(np.mean(run_summary["retrieval_failure_unsatisfied"])) if run_summary["retrieval_failure_unsatisfied"] else 0.0,
        "semantic_materialization_failure_rate": float(np.mean(run_summary["semantic_materialization_failure"])) if run_summary["semantic_materialization_failure"] else 0.0,
        "control_failure_after_retrieval_rate": float(np.mean(run_summary["control_failure_after_retrieval"])) if run_summary["control_failure_after_retrieval"] else 0.0,
        "oracle_retrieval_activation_rate": float(np.mean(run_summary["oracle_retrieval_activated"])) if run_summary["oracle_retrieval_activated"] else 0.0,
        "oracle_materialization_activation_rate": float(np.mean(run_summary["oracle_materialization_activated"])) if run_summary["oracle_materialization_activated"] else 0.0,
        "oracle_controller_activation_rate": float(np.mean(run_summary["oracle_controller_activated"])) if run_summary["oracle_controller_activated"] else 0.0,
        "final_nodes": final_nodes,
        "final_edges": final_edges,
    }
    return summary


def run_songline_experiment(args, export_outputs=True, verbose=True):
    args = apply_milestone_mode(args)
    ensure_dir(args.out_dir)
    intent_replan_cooldown_steps = max(0, int(getattr(args, "intent_replan_cooldown_steps", 4)))
    goal_rejoin_guard_steps = max(0, int(getattr(args, "goal_rejoin_guard_steps", 4)))

    env = build_env(args)
    rng = np.random.RandomState(args.seed)
    method_name = make_method_name(args.agent_mode, args.songline_policy)

    tokenizer = None
    scene_encoder = None
    memory = None
    rollout_planner = None
    maneuver_selector = None
    trajectory_planner = None
    if args.agent_mode == "songline":
        tokenizer, scene_encoder, memory, rollout_planner = build_memory(args)
        maneuver_selector, trajectory_planner = build_local_planner(args)
    else:
        _, trajectory_planner = build_local_planner(args)

    run_summary = {
        "env_id": args.env_id,
        "task_mode": getattr(args, "task_mode", "default"),
        "agent_mode": args.agent_mode,
        "songline_policy": args.songline_policy,
        "method": method_name,
        "episodes": args.episodes,
        "max_steps": args.max_steps,
        "seed": args.seed,
        "env_change_mode": args.env_change_mode,
        "change_after_episode": args.change_after_episode,
        "intent_mode": args.intent_mode,
        "intent_selection_mode": args.intent_selection_mode,
        "intent_type": args.intent_type,
        "intent_handoff_mode": args.intent_handoff_mode,
        "goal_rejoin_guard_mode": args.goal_rejoin_guard_mode,
        "goal_rejoin_target_mode": args.goal_rejoin_target_mode,
        "semantic_retrieval_mode": getattr(args, "semantic_retrieval_mode", "concept_recall_v1"),
        "oracle_retrieval_enabled": int(bool(getattr(args, "oracle_retrieval", False))),
        "oracle_materialization_enabled": int(bool(getattr(args, "oracle_materialization", False))),
        "oracle_controller_enabled": int(bool(getattr(args, "oracle_controller", False))),
        "semantic_tag_dropout_prob": float(getattr(args, "semantic_tag_dropout_prob", 0.0)),
        "semantic_tag_false_positive_prob": float(getattr(args, "semantic_tag_false_positive_prob", 0.0)),
        "semantic_tag_false_positive_value": float(getattr(args, "semantic_tag_false_positive_value", 0.35)),
        "water_success_radius": int(getattr(args, "water_success_radius", 1)),
        "rest_success_radius": int(getattr(args, "rest_success_radius", 1)),
        "thirst_on_threshold": float(getattr(args, "thirst_on_threshold", 0.10)),
        "thirst_off_threshold": float(getattr(args, "thirst_off_threshold", 0.04)),
        "water_local_activation_threshold": float(getattr(args, "water_local_activation_threshold", 0.0)),
        "water_local_hold_threshold": float(getattr(args, "water_local_hold_threshold", 0.0)),
        "rest_energy_on_threshold": float(getattr(args, "rest_energy_on_threshold", 0.95)),
        "rest_energy_off_threshold": float(getattr(args, "rest_energy_off_threshold", 0.98)),
        "rest_local_activation_threshold": float(getattr(args, "rest_local_activation_threshold", 0.0)),
        "rest_local_hold_threshold": float(getattr(args, "rest_local_hold_threshold", 0.0)),
        "local_resource_guidance_enabled": int(local_resource_guidance_enabled(args)),
        "goal_rejoin_fallback_assists_enabled": int(goal_rejoin_fallback_assists_enabled(args)),
        "episode_returns": [],
        "episode_lengths": [],
        "successes": [],
        "successes_pre_change": [],
        "successes_post_change": [],
        "graph_nodes": [],
        "graph_edges": [],
        "intervention_rate": [],
        "plan_hit_rate": [],
        "phrase_length_mean": [],
        "subgoal_reached": [],
        "goal_distance_delta_per_intervention": [],
        "node_reuse_rate": [],
        "new_nodes_per_episode": [],
        "graph_path_length": [],
        "has_gap_aligned": [],
        "has_safe_crossing": [],
        "has_post_hazard": [],
        "has_final_exit_maneuver": [],
        "has_resume_to_goal": [],
        "has_post_hazard_progress": [],
        "has_resume_to_goal_progress": [],
        "post_hazard_to_success": [],
        "resume_to_goal_to_success": [],
        "max_phase_depth": [],
        "query_attempt_count": [],
        "query_nonempty_rate": [],
        "retrieval_precision_at_k": [],
        "query_satisfaction_rate": [],
        "semantic_target_materialization_rate": [],
        "semantic_target_materialized_any": [],
        "post_retrieval_completion": [],
        "local_resource_guidance_used": [],
        "goal_rejoin_fallback_assist_used": [],
        "retrieval_failure_empty": [],
        "retrieval_failure_unsatisfied": [],
        "semantic_materialization_failure": [],
        "control_failure_after_retrieval": [],
        "oracle_retrieval_activated": [],
        "oracle_materialization_activated": [],
        "oracle_controller_activated": [],
        "episode_metrics": [],
    }

    total_step_idx = 0
    seen_songline_nodes = set()
    debug_trace_rows = []
    demo_frames = []
    demo_frame_meta = []

    for ep in range(args.episodes):
        obs, info = env.reset(seed=args.seed + ep)
        task_info = dict(info or {})
        args.episode_intent_type_override = str(task_info.get("episode_intent_type", args.intent_type))
        del obs, info
        if memory is not None and hasattr(memory, "start_episode"):
            memory.start_episode(
                episode_id=int(ep + 1),
                env_id=str(args.env_id),
                task_mode=str(getattr(args, "task_mode", "default")),
            )
        change_active = apply_env_change(
            env,
            episode_idx=ep,
            env_change_mode=args.env_change_mode,
            change_after_episode=args.change_after_episode,
        )
        if tokenizer is not None and hasattr(tokenizer, "reset"):
            tokenizer.reset()
        if trajectory_planner is not None and hasattr(trajectory_planner, "reset"):
            trajectory_planner.reset()

        goal_xy = get_goal_position(env)
        water_xy = get_water_position(env)
        rest_xy = get_rest_position(env)
        episode_return = 0.0
        success = 0
        previous_goal_distance = None
        subgoal_xy = None
        step_count = 0
        interventions_this_episode = 0
        subgoal_hits_this_episode = 0
        distance_delta_sum = 0.0
        active_intervention_distance = None
        active_subgoal_key = None
        active_graph_path_length = 0
        graph_path_lengths = []
        unique_songline_nodes_this_episode = set()
        new_nodes_start = 0 if memory is None else len(memory.nodes)
        ep_memory = build_episode_memory() if args.agent_mode == "greedy_episodic" else None
        no_override_suggestions = 0
        previous_token_label = None
        active_target_node_id = None
        active_next_node_id = None
        hazard_phase_active = False
        hazard_phase_intervened = False
        active_maneuver_command = None
        active_maneuver_command_type = None
        active_planner_debug = None
        active_intent_type = None
        active_intent_reason = "episode_init"
        intent_replan_cooldown_left = 0
        goal_rejoin_guard_active = False
        goal_rejoin_guard_steps_left = 0
        goal_rejoin_guard_best_distance = None
        episode_intent_type = parse_intent_type(effective_intent_type_name(args))
        agent_state = AgentState(active_intent=episode_intent_type)
        intent_policy = (
            IntentPolicy(
                hazard_intent=episode_intent_type,
                water_intent=(
                    IntentType.FIND_WATER_SOURCE
                    if episode_intent_type == IntentType.FIND_WATER_SOURCE
                    else None
                ),
                rest_intent=(
                    IntentType.FIND_SAFE_REST_ZONE
                    if episode_intent_type == IntentType.FIND_SAFE_REST_ZONE
                    else None
                ),
                thirst_on_threshold=float(getattr(args, "thirst_on_threshold", 0.10)),
                thirst_off_threshold=float(getattr(args, "thirst_off_threshold", 0.04)),
                water_local_activation_threshold=float(getattr(args, "water_local_activation_threshold", 0.0)),
                water_local_hold_threshold=float(getattr(args, "water_local_hold_threshold", 0.0)),
                rest_energy_on_threshold=float(getattr(args, "rest_energy_on_threshold", 0.95)),
                rest_energy_off_threshold=float(getattr(args, "rest_energy_off_threshold", 0.98)),
                rest_local_activation_threshold=float(getattr(args, "rest_local_activation_threshold", 0.0)),
                rest_local_hold_threshold=float(getattr(args, "rest_local_hold_threshold", 0.0)),
            )
            if args.intent_selection_mode == "state_v1"
            else None
        )
        hazard_commit_active = False
        hazard_commit_dir = None
        hazard_commit_steps_left = 0
        exit_hazard_commit_active = False
        exit_hazard_commit_dir = None
        exit_hazard_commit_steps_left = 0
        final_exit_active = False
        final_exit_dir = None
        final_exit_steps_left = 0
        resume_to_goal_active = False
        resume_to_goal_steps_left = 0
        phase_flags = {
            "gap_aligned": 0,
            "safe_crossing": 0,
            "post_hazard": 0,
            "final_exit_maneuver": 0,
            "resume_to_goal": 0,
        }
        oracle_retrieval_activated = 0
        oracle_materialization_activated = 0
        oracle_controller_activated = 0
        post_hazard_armed = 0
        resume_to_goal_armed = 0
        has_post_hazard_progress = 0
        has_resume_to_goal_progress = 0
        has_goal_rejoin_materialization_failure = 0
        water_task_success = 0
        rest_task_success = 0
        local_resource_guidance_used = 0
        goal_rejoin_fallback_assist_used = 0
        record_demo_episode = bool(
            getattr(args, "record_demo", False)
            and int(ep + 1) == int(getattr(args, "demo_episode", 1))
        )
        if record_demo_episode:
            frame = env.render()
            if frame is not None:
                demo_frames.append(np.asarray(frame, dtype=np.uint8))
                demo_frame_meta.append(
                    {
                        "episode": int(ep + 1),
                        "step": 0,
                        "token": "reset",
                        "action": None,
                        "intent": None,
                        "rejoin_source": "none",
                        "hazard_adjacent": 0,
                        "goal_alignment": 0.0,
                        "pos": tuple(int(v) for v in env.unwrapped.agent_pos),
                        "subgoal": None,
                        "distance_after": None if goal_xy is None else int(manhattan(np.array(env.unwrapped.agent_pos, dtype=np.int32), goal_xy)),
                        "water_distance": None if water_xy is None else int(manhattan(np.array(env.unwrapped.agent_pos, dtype=np.int32), water_xy)),
                        "rest_distance": None if rest_xy is None else int(manhattan(np.array(env.unwrapped.agent_pos, dtype=np.int32), rest_xy)),
                        "reward": 0.0,
                        "event": "episode_start",
                    }
                )

        for step in range(args.max_steps):
            step_count = step + 1
            unwrapped = env.unwrapped
            agent_xy = np.array(unwrapped.agent_pos, dtype=np.int32)
            current_graph_node_id = None
            planner_query = None
            planner_query_tag_name = None
            query_debug_should_record = False
            distance_before = None if goal_xy is None else manhattan(agent_xy, goal_xy)
            scene = None
            scene_token = None
            token_label = None
            trace_intent_switched = 0
            trace_forced_intent_replan = 0
            trace_forced_goal_rejoin_replan = 0
            trace_exited_hazard_recovery_intent = 0
            trace_goal_rejoin_handoff_suppressed = 0
            trace_goal_rejoin_target_materialized = 0
            trace_goal_rejoin_target_source = "none"
            trace_goal_rejoin_fallback_used = 0
            trace_stable_rejoin_waypoint_used = 0
            trace_stable_rejoin_waypoint_x = None
            trace_stable_rejoin_waypoint_y = None
            trace_rejoin_target_hazard_adjacent = 0
            trace_rejoin_target_goal_alignment = 0.0
            trace_goal_rejoin_graph_node_considered = 0
            trace_goal_rejoin_graph_node_accepted = 0
            trace_goal_rejoin_graph_node_rejected = 0
            trace_goal_rejoin_graph_node_reject_reason = "none"
            trace_goal_rejoin_graph_node_goal_region_confidence = 0.0
            trace_goal_rejoin_graph_node_hazard_adjacent = 0
            trace_goal_rejoin_graph_node_goal_alignment = 0.0
            trace_goal_rejoin_stable_waypoint_available = 0
            trace_previous_active_intent = None if active_intent_type is None else str(active_intent_type.value)
            trace_new_active_intent = trace_previous_active_intent
            trace_intent_switch_reason = active_intent_reason
            trace_previous_target_node_id = active_target_node_id
            trace_new_target_node_id = active_target_node_id
            local_resource_plan = None

            if args.agent_mode == "songline":
                prev_graph_node_id = memory.current_phrase_id
                if args.token_source == "symbolic_hash":
                    obs_vec = local_symbolic_observation(env, radius=args.scene_radius)
                    token = tokenizer.encode(obs_vec)
                    token_label = str(token)
                else:
                    scene = scene_encoder.encode(env)
                    scene_token = tokenizer.tokenize(scene)
                    scene_token = maybe_perturb_scene_token(scene_token, args=args, rng=rng)
                    token = scene_token_to_int(scene_token)
                    token_label = str(scene_token.token_type)
                observe_result = memory.observe(
                    scene_token=scene_token,
                    scene_state=scene,
                    agent_state=agent_state,
                    step_info={
                        "phase": "pre_action",
                        "step_idx": int(total_step_idx),
                        "token_id": int(token),
                        "token_label": str(token_label),
                        "pose_xy": agent_xy,
                        "goal_xy": goal_xy,
                        "reward": 0.0,
                        "risk": scene_risk_proxy(scene) if args.token_source != "symbolic_hash" else None,
                        "comfort_cost": scene_comfort_proxy(scene) if args.token_source != "symbolic_hash" else None,
                        "goal_alignment": scene.route_context.goal_alignment if args.token_source != "symbolic_hash" else None,
                    },
                )
                prev_graph_node_id = observe_result.get("previous_graph_node_id")
                current_graph_node_id = observe_result.get("current_graph_node_id")
                is_new_node = bool(observe_result.get("is_new_graph_node", False))
                if is_new_node and memory.current_phrase_id is not None:
                    unique_songline_nodes_this_episode.add(memory.current_phrase_id)
                    if memory.current_phrase_id in seen_songline_nodes:
                        pass
                    else:
                        seen_songline_nodes.add(memory.current_phrase_id)
                prior_active_intent_type = active_intent_type
                prior_task_phase = str(agent_state.task_phase)
                force_intent_replan = False
                if args.intent_mode != "none":
                    agent_state = update_agent_state(
                        agent_state,
                        scene=scene,
                        token_label=token_label,
                    )
                    active_intent_type, active_intent_reason = resolve_active_intent_type(
                        args,
                        agent_state=agent_state,
                        intent_policy=intent_policy,
                        scene=scene,
                    )
                    agent_state.active_intent = active_intent_type
                    agent_state.active_intent_reason = str(active_intent_reason)
                    trace_previous_active_intent = None if prior_active_intent_type is None else str(prior_active_intent_type.value)
                    trace_new_active_intent = None if active_intent_type is None else str(active_intent_type.value)
                    trace_intent_switch_reason = str(active_intent_reason)
                    trace_intent_switched = int(
                        prior_active_intent_type is not None and prior_active_intent_type != active_intent_type
                    )
                    entered_hazard_navigation = (
                        prior_task_phase != "hazard_navigation"
                        and str(agent_state.task_phase) == "hazard_navigation"
                    )
                    switched_to_defensive_intent = (
                        active_intent_type is not None
                        and is_defensive_intent(active_intent_type)
                        and active_intent_type != prior_active_intent_type
                    )
                    exited_hazard_recovery_intent = bool(
                        should_use_post_recovery_goal_handoff(args)
                        and prior_active_intent_type == IntentType.HAZARD_RECOVERY_EXIT
                        and active_intent_type == IntentType.FIND_GOAL_REGION
                    )
                    if (
                        exited_hazard_recovery_intent
                        and should_use_goal_rejoin_guard(args)
                        and goal_rejoin_guard_active
                        and goal_rejoin_guard_steps_left > 0
                    ):
                        trace_goal_rejoin_handoff_suppressed = 1
                        exited_hazard_recovery_intent = False
                    trace_exited_hazard_recovery_intent = int(exited_hazard_recovery_intent)
                    force_intent_replan = bool(
                        args.songline_policy == "graph_path"
                        and getattr(args, "intent_selection_mode", "fixed") == "state_v1"
                        and intent_replan_cooldown_left <= 0
                        and (
                            entered_hazard_navigation
                            or switched_to_defensive_intent
                            or exited_hazard_recovery_intent
                        )
                    )
                    if force_intent_replan:
                        cleared = clear_active_graph_plan()
                        subgoal_xy = cleared["subgoal_xy"]
                        active_subgoal_key = cleared["active_subgoal_key"]
                        active_graph_path_length = cleared["active_graph_path_length"]
                        active_target_node_id = cleared["active_target_node_id"]
                        active_next_node_id = cleared["active_next_node_id"]
                        active_maneuver_command = cleared["active_maneuver_command"]
                        active_maneuver_command_type = cleared["active_maneuver_command_type"]
                        active_planner_debug = cleared["active_planner_debug"]
                        trace_forced_intent_replan = 1
                        trace_forced_goal_rejoin_replan = int(exited_hazard_recovery_intent)
                        intent_replan_cooldown_left = intent_replan_cooldown_steps
                        if exited_hazard_recovery_intent and should_use_goal_rejoin_guard(args):
                            goal_rejoin_guard_active = True
                            goal_rejoin_guard_steps_left = goal_rejoin_guard_steps
                            goal_rejoin_guard_best_distance = distance_before

                hazard_phase_active = is_hazard_phase_token(token_label)
                post_exit_pending = bool(
                    (final_exit_active and final_exit_steps_left > 0)
                    or (resume_to_goal_active and resume_to_goal_steps_left > 0)
                )
                if not hazard_phase_active and not post_exit_pending:
                    hazard_phase_intervened = False
                    hazard_commit_active = False
                    hazard_commit_dir = None
                    hazard_commit_steps_left = 0
                    exit_hazard_commit_active = False
                    exit_hazard_commit_dir = None
                    exit_hazard_commit_steps_left = 0
                    final_exit_active = False
                    final_exit_dir = None
                    final_exit_steps_left = 0

                if token_label == "safe_crossing":
                    exit_hazard_commit_active = True
                    exit_hazard_commit_dir = int(env.unwrapped.agent_dir)
                    exit_hazard_commit_steps_left = max(exit_hazard_commit_steps_left, 2)
                elif token_label == "post_hazard":
                    final_exit_active = True
                    final_exit_dir = int(env.unwrapped.agent_dir)
                    final_exit_steps_left = max(final_exit_steps_left, 2)

                if should_run_graph_intervention(
                    args,
                    step=step,
                    token_label=token_label,
                    active_subgoal_key=active_subgoal_key,
                    hazard_phase_intervened=hazard_phase_intervened,
                ) or force_intent_replan:
                    proposal = memory.suggest_subgoal(top_k=args.top_k_goals)
                    if proposal is not None:
                        no_override_suggestions += 1

                    if args.songline_policy == "subgoal_controller" and proposal is not None:
                        gx = int(round(proposal["goal_xy"][0]))
                        gy = int(round(proposal["goal_xy"][1]))
                        gx = max(0, min(gx, env.unwrapped.grid.width - 1))
                        gy = max(0, min(gy, env.unwrapped.grid.height - 1))
                        subgoal_xy = np.array([gx, gy], dtype=np.int32)
                        interventions_this_episode += 1
                        active_intervention_distance = distance_before
                        active_subgoal_key = (int(subgoal_xy[0]), int(subgoal_xy[1]))
                        active_graph_path_length = 0
                        active_target_node_id = int(proposal["node_id"])
                        active_next_node_id = int(proposal["node_id"])
                        if hazard_phase_active:
                            hazard_phase_intervened = True

                    if args.songline_policy == "graph_path":
                        preserve_commit = bool(
                            (hazard_commit_active and hazard_commit_steps_left > 0 and hazard_phase_active)
                            or (exit_hazard_commit_active and exit_hazard_commit_steps_left > 0)
                            or (final_exit_active and final_exit_steps_left > 0)
                            or (resume_to_goal_active and resume_to_goal_steps_left > 0)
                        )
                        if force_intent_replan or not preserve_commit:
                            query_debug_should_record = True
                            planner_query = current_planner_query(
                                args,
                                goal_xy=goal_xy,
                                active_intent_type=active_intent_type,
                                agent_state=agent_state,
                            )
                            planner_query_tag_name = None
                            if planner_query is not None and getattr(planner_query, "target_predicate", None) is not None:
                                planner_query_tag_name = planner_query.target_predicate.tag_name
                            oracle_waypoint_xy = None
                            oracle_waypoint_source = "none"
                            if planner_query is not None and (
                                bool(getattr(args, "oracle_retrieval", False))
                                or bool(getattr(args, "oracle_materialization", False))
                            ):
                                oracle_waypoint_xy, oracle_waypoint_source = select_oracle_semantic_waypoint(
                                    args=args,
                                    env=env,
                                    active_intent_type=active_intent_type,
                                    goal_xy=goal_xy,
                                    water_xy=water_xy,
                                    rest_xy=rest_xy,
                                )
                            if planner_query is not None and bool(getattr(args, "oracle_retrieval", False)) and oracle_waypoint_xy is not None:
                                oracle_retrieval_activated = 1
                                path_plan = make_oracle_path_plan(
                                    oracle_waypoint_xy,
                                    planner_query=planner_query,
                                    source=oracle_waypoint_source,
                                )
                            else:
                                path_plan = select_graph_waypoint(
                                    memory,
                                    rollout_planner,
                                    maneuver_selector,
                                    top_k=args.top_k_goals,
                                    rollout_horizon=args.graph_rollout_horizon,
                                    current_token_label=token_label,
                                    env=env,
                                    goal_xy=goal_xy,
                                    planner_query=planner_query,
                                )
                                if (
                                    path_plan is None
                                    and planner_query is not None
                                    and goal_xy is None
                                ):
                                    path_plan = select_semantic_waypoint_fallback(
                                        memory,
                                        planner_query=planner_query,
                                        current_node_id=current_phrase_node(memory),
                                        source_xy=agent_xy,
                                        top_k=args.top_k_goals,
                                    )
                                if (
                                    path_plan is None
                                    and planner_query is not None
                                    and bool(getattr(args, "oracle_materialization", False))
                                    and oracle_waypoint_xy is not None
                                ):
                                    oracle_materialization_activated = 1
                                    path_plan = make_oracle_path_plan(
                                        oracle_waypoint_xy,
                                        planner_query=planner_query,
                                        source=oracle_waypoint_source,
                                    )
                            if path_plan is not None:
                                planner_debug = dict(path_plan.get("planner_debug", {}))
                                if active_intent_type is not None:
                                    planner_debug["resolved_active_intent_type"] = str(active_intent_type.value)
                                if trace_forced_goal_rejoin_replan:
                                    decision = _select_rejoin_target_source(
                                        args,
                                        env=env,
                                        source_xy=agent_xy,
                                        goal_xy=goal_xy,
                                        graph_waypoint_xy=path_plan["waypoint_xy"],
                                        planner_debug=planner_debug,
                                    )
                                    trace_goal_rejoin_graph_node_considered = int(decision["graph_node_considered"])
                                    trace_goal_rejoin_graph_node_accepted = int(decision["graph_node_accepted"])
                                    trace_goal_rejoin_graph_node_rejected = int(decision["graph_node_rejected"])
                                    trace_goal_rejoin_graph_node_reject_reason = str(decision["graph_node_reject_reason"])
                                    trace_goal_rejoin_graph_node_goal_region_confidence = float(decision["graph_node_goal_region_confidence"])
                                    trace_goal_rejoin_graph_node_hazard_adjacent = int(decision["graph_node_hazard_adjacent"])
                                    trace_goal_rejoin_graph_node_goal_alignment = float(decision["graph_node_goal_alignment"])
                                    trace_goal_rejoin_stable_waypoint_available = int(decision["stable_waypoint_available"])
                                    selected_waypoint = decision["selected_waypoint_xy"]
                                    selected_source = str(decision["selected_source"])
                                    if selected_waypoint is not None:
                                        subgoal_xy = np.asarray(selected_waypoint, dtype=np.int32).copy()
                                        interventions_this_episode += 1
                                        active_intervention_distance = distance_before
                                        active_subgoal_key = (int(subgoal_xy[0]), int(subgoal_xy[1]))
                                        if selected_source == "graph_node":
                                            active_graph_path_length = int(path_plan["graph_path_length"])
                                            graph_path_lengths.append(active_graph_path_length)
                                            active_target_node_id = None if path_plan["target_node_id"] is None else int(path_plan["target_node_id"])
                                            active_next_node_id = (
                                                None
                                                if path_plan["next_node_id"] is None
                                                else int(path_plan["next_node_id"])
                                            )
                                            active_maneuver_command = dict(path_plan["maneuver_command"])
                                            active_maneuver_command_type = str(active_maneuver_command.get("command_type"))
                                        else:
                                            active_graph_path_length = 0
                                            active_target_node_id = None
                                            active_next_node_id = None
                                            active_maneuver_command = {
                                                "command_type": "go_to_waypoint",
                                                "waypoint_xy": tuple(int(v) for v in subgoal_xy),
                                            }
                                            active_maneuver_command_type = "go_to_waypoint"
                                        active_planner_debug = planner_debug
                                        active_planner_debug["goal_rejoin_target_materialized"] = True
                                        active_planner_debug["goal_rejoin_target_source"] = selected_source
                                        active_planner_debug["goal_rejoin_graph_node_considered"] = int(decision["graph_node_considered"])
                                        active_planner_debug["goal_rejoin_graph_node_accepted"] = int(decision["graph_node_accepted"])
                                        active_planner_debug["goal_rejoin_graph_node_rejected"] = int(decision["graph_node_rejected"])
                                        active_planner_debug["goal_rejoin_graph_node_reject_reason"] = str(decision["graph_node_reject_reason"])
                                        active_planner_debug["goal_rejoin_graph_node_goal_region_confidence"] = float(decision["graph_node_goal_region_confidence"])
                                        active_planner_debug["goal_rejoin_graph_node_hazard_adjacent"] = int(decision["graph_node_hazard_adjacent"])
                                        active_planner_debug["goal_rejoin_graph_node_goal_alignment"] = float(decision["graph_node_goal_alignment"])
                                        active_planner_debug["goal_rejoin_stable_waypoint_available"] = int(decision["stable_waypoint_available"])
                                        if selected_source == "stable_rejoin_waypoint":
                                            trace_stable_rejoin_waypoint_used = 1
                                            trace_stable_rejoin_waypoint_x = int(subgoal_xy[0])
                                            trace_stable_rejoin_waypoint_y = int(subgoal_xy[1])
                                        if hazard_phase_active:
                                            hazard_phase_intervened = True
                                        trace_new_target_node_id = active_target_node_id
                                        trace_goal_rejoin_target_materialized = 1
                                        trace_goal_rejoin_target_source = selected_source
                                        trace_goal_rejoin_fallback_used = int(selected_source != "graph_node")
                                        goal_rejoin_fallback_assist_used = max(
                                            goal_rejoin_fallback_assist_used,
                                            int(selected_source != "graph_node"),
                                        )
                                        waypoint_stats = _target_waypoint_stats(env, agent_xy, subgoal_xy, goal_xy)
                                        trace_rejoin_target_hazard_adjacent = int(waypoint_stats["hazard_adjacent"])
                                        trace_rejoin_target_goal_alignment = float(waypoint_stats["goal_alignment"])
                                    elif bool(getattr(args, "oracle_materialization", False)) and oracle_waypoint_xy is not None:
                                        oracle_materialization_activated = 1
                                        subgoal_xy = np.asarray(oracle_waypoint_xy, dtype=np.int32).copy()
                                        interventions_this_episode += 1
                                        active_intervention_distance = distance_before
                                        active_subgoal_key = (int(subgoal_xy[0]), int(subgoal_xy[1]))
                                        active_graph_path_length = 0
                                        active_target_node_id = None
                                        active_next_node_id = None
                                        active_maneuver_command = {
                                            "command_type": "go_to_waypoint",
                                            "waypoint_xy": tuple(int(v) for v in subgoal_xy),
                                        }
                                        active_maneuver_command_type = "go_to_waypoint"
                                        active_planner_debug = planner_debug
                                        active_planner_debug["goal_rejoin_target_materialized"] = True
                                        active_planner_debug["goal_rejoin_target_source"] = str(oracle_waypoint_source)
                                        trace_new_target_node_id = active_target_node_id
                                        trace_goal_rejoin_target_materialized = 1
                                        trace_goal_rejoin_target_source = str(oracle_waypoint_source)
                                        trace_goal_rejoin_fallback_used = 1
                                        goal_rejoin_fallback_assist_used = max(goal_rejoin_fallback_assist_used, 1)
                                        waypoint_stats = _target_waypoint_stats(env, agent_xy, subgoal_xy, goal_xy)
                                        trace_rejoin_target_hazard_adjacent = int(waypoint_stats["hazard_adjacent"])
                                        trace_rejoin_target_goal_alignment = float(waypoint_stats["goal_alignment"])
                                    else:
                                        active_planner_debug = planner_debug
                                        active_planner_debug["goal_rejoin_target_materialized"] = False
                                        active_planner_debug["goal_rejoin_target_source"] = "none"
                                        has_goal_rejoin_materialization_failure = 1
                                else:
                                    subgoal_xy = path_plan["waypoint_xy"].copy()
                                    interventions_this_episode += 1
                                    active_intervention_distance = distance_before
                                    active_subgoal_key = (int(subgoal_xy[0]), int(subgoal_xy[1]))
                                    active_graph_path_length = int(path_plan["graph_path_length"])
                                    graph_path_lengths.append(active_graph_path_length)
                                    active_target_node_id = None if path_plan["target_node_id"] is None else int(path_plan["target_node_id"])
                                    active_next_node_id = (
                                        None
                                        if path_plan["next_node_id"] is None
                                        else int(path_plan["next_node_id"])
                                    )
                                    active_maneuver_command = dict(path_plan["maneuver_command"])
                                    active_maneuver_command_type = str(active_maneuver_command.get("command_type"))
                                    active_planner_debug = planner_debug
                                    active_planner_debug["goal_rejoin_target_materialized"] = True
                                    active_planner_debug["goal_rejoin_target_source"] = "graph_plan"
                                    if hazard_phase_active:
                                        hazard_phase_intervened = True
                                    trace_new_target_node_id = active_target_node_id
                            elif planner_query is not None:
                                active_planner_debug = {
                                    "used_intent_query": True,
                                    "intent_type": None if active_intent_type is None else str(active_intent_type.value),
                                    "resolved_active_intent_type": None if active_intent_type is None else str(active_intent_type.value),
                                    "query_tag_name": planner_query_tag_name,
                                    "candidate_node_ids": [],
                                    "candidate_base_utilities": {},
                                    "candidate_tag_confidences": {},
                                    "candidate_intent_scores": {},
                                    "selected_tag_confidence": None,
                                    "selected_node_semantic_tag_confidence": {},
                                    "selected_plan_utility": 0.0,
                                    "plan_source": "semantic_query_empty",
                                    "goal_rejoin_target_materialized": False,
                                    "goal_rejoin_target_source": "none",
                                }
                            elif trace_forced_goal_rejoin_replan:
                                active_planner_debug = {
                                    "used_intent_query": bool(planner_query is not None),
                                    "intent_type": None if active_intent_type is None else str(active_intent_type.value),
                                    "resolved_active_intent_type": None if active_intent_type is None else str(active_intent_type.value),
                                    "query_tag_name": planner_query_tag_name,
                                    "candidate_node_ids": [],
                                    "candidate_base_utilities": {},
                                    "candidate_tag_confidences": {},
                                    "selected_tag_confidence": None,
                                    "selected_node_semantic_tag_confidence": {},
                                    "selected_plan_utility": 0.0,
                                    "goal_rejoin_target_materialized": False,
                                    "goal_rejoin_target_source": "none",
                                    "goal_rejoin_graph_node_considered": 0,
                                    "goal_rejoin_graph_node_accepted": 0,
                                    "goal_rejoin_graph_node_rejected": 0,
                                    "goal_rejoin_graph_node_reject_reason": "no_graph_plan",
                                    "goal_rejoin_graph_node_goal_region_confidence": 0.0,
                                    "goal_rejoin_graph_node_hazard_adjacent": 0,
                                    "goal_rejoin_graph_node_goal_alignment": 0.0,
                                    "goal_rejoin_stable_waypoint_available": 0,
                                }
                                fallback_waypoint = None
                                fallback_source = "none"
                                if should_use_stable_goal_rejoin_waypoint(args) or should_use_source_selected_goal_rejoin(args):
                                    stable_waypoint = _stable_goal_rejoin_waypoint(
                                        env,
                                        goal_xy,
                                        avoid_hazard_adjacent=should_use_strict_stable_goal_rejoin(args),
                                        max_radius=4 if should_use_strict_stable_goal_rejoin(args) else 2,
                                    )
                                    trace_goal_rejoin_stable_waypoint_available = int(stable_waypoint is not None)
                                    active_planner_debug["goal_rejoin_stable_waypoint_available"] = int(stable_waypoint is not None)
                                    if stable_waypoint is not None:
                                        fallback_waypoint = np.asarray(stable_waypoint, dtype=np.int32).copy()
                                        fallback_source = "stable_rejoin_waypoint"
                                        trace_stable_rejoin_waypoint_used = 1
                                        trace_stable_rejoin_waypoint_x = int(fallback_waypoint[0])
                                        trace_stable_rejoin_waypoint_y = int(fallback_waypoint[1])
                                    elif goal_xy is not None:
                                        fallback_waypoint = np.asarray(goal_xy, dtype=np.int32).copy()
                                        fallback_source = "goal_xy_fallback"
                                elif should_use_goal_rejoin_target_fallback(args) and goal_xy is not None:
                                    fallback_waypoint = np.asarray(goal_xy, dtype=np.int32).copy()
                                    fallback_source = "goal_xy_fallback"

                                if fallback_waypoint is not None:
                                    subgoal_xy = fallback_waypoint
                                    interventions_this_episode += 1
                                    active_intervention_distance = distance_before
                                    active_subgoal_key = (int(subgoal_xy[0]), int(subgoal_xy[1]))
                                    active_graph_path_length = 0
                                    active_target_node_id = None
                                    active_next_node_id = None
                                    active_maneuver_command = {
                                        "command_type": "go_to_waypoint",
                                        "waypoint_xy": tuple(int(v) for v in subgoal_xy),
                                    }
                                    active_maneuver_command_type = "go_to_waypoint"
                                    active_planner_debug["goal_rejoin_target_materialized"] = True
                                    active_planner_debug["goal_rejoin_target_source"] = fallback_source
                                    trace_goal_rejoin_target_materialized = 1
                                    trace_goal_rejoin_target_source = fallback_source
                                    trace_goal_rejoin_fallback_used = int(fallback_source != "graph_node")
                                    goal_rejoin_fallback_assist_used = max(
                                        goal_rejoin_fallback_assist_used,
                                        int(fallback_source != "graph_node"),
                                    )
                                    waypoint_stats = _target_waypoint_stats(env, agent_xy, subgoal_xy, goal_xy)
                                    trace_rejoin_target_hazard_adjacent = int(waypoint_stats["hazard_adjacent"])
                                    trace_rejoin_target_goal_alignment = float(waypoint_stats["goal_alignment"])
                                if not trace_goal_rejoin_target_materialized:
                                    has_goal_rejoin_materialization_failure = 1

                            if query_debug_should_record and hasattr(memory, "record_query"):
                                selected_source = "none"
                                if active_planner_debug is not None:
                                    selected_source = str(active_planner_debug.get("goal_rejoin_target_source", "none"))
                                if selected_source in {"none", ""} and active_target_node_id is not None:
                                    selected_source = "graph_plan"
                                memory.record_query(
                                    step_idx=int(total_step_idx),
                                    current_node_id=current_graph_node_id,
                                    planner_query=planner_query,
                                    planner_debug=active_planner_debug,
                                    selected_node_id=active_target_node_id,
                                    selected_source=selected_source,
                                )

                if (
                    args.commit_to_corridor
                    and args.agent_mode == "songline"
                    and not hazard_commit_active
                    and should_activate_hazard_commit(
                        scene=scene,
                        hazard_phase_active=hazard_phase_active,
                        subgoal_xy=subgoal_xy,
                    )
                ):
                    hazard_commit_active = True
                    hazard_commit_dir = int(env.unwrapped.agent_dir)
                    hazard_commit_steps_left = max(hazard_commit_steps_left, 3)

                if local_resource_guidance_enabled(args):
                    local_resource_plan = local_resource_guidance(
                        env,
                        scene=scene,
                        active_intent_type=active_intent_type,
                        radius=max(1, int(getattr(args, "scene_radius", 1))),
                    )

            action = random_safe_action(rng)
            if args.agent_mode == "greedy":
                command = {"command_type": "go_to_waypoint", "waypoint_xy": goal_xy}
                action = trajectory_planner.next_action(env, command) if goal_xy is not None else random_safe_action(rng)
            elif args.agent_mode == "greedy_episodic":
                episodic_target = None
                if step % args.suggest_every == 0:
                    episodic_target = choose_episodic_waypoint(ep_memory)
                    if episodic_target is not None:
                        interventions_this_episode += 1
                        active_intervention_distance = distance_before
                        active_subgoal_key = (int(episodic_target[0]), int(episodic_target[1]))
                if episodic_target is None and ep_memory["active_waypoint"] is not None:
                    episodic_target = ep_memory["active_waypoint"]["pos"]
                if episodic_target is not None and rng.rand() > args.epsilon:
                    subgoal_xy = episodic_target.copy()
                    action = trajectory_planner.next_action(
                        env,
                        {"command_type": "go_to_waypoint", "waypoint_xy": subgoal_xy},
                    )
                else:
                    action = trajectory_planner.next_action(
                        env,
                        {"command_type": "go_to_waypoint", "waypoint_xy": goal_xy},
                    ) if goal_xy is not None else random_safe_action(rng)
            elif args.agent_mode == "songline":
                if args.songline_policy == "no_override":
                    action = trajectory_planner.next_action(
                        env,
                        {"command_type": "go_to_waypoint", "waypoint_xy": goal_xy},
                    ) if goal_xy is not None else random_safe_action(rng)
                elif args.songline_policy == "subgoal_controller":
                    if subgoal_xy is not None and rng.rand() > args.epsilon:
                        action = trajectory_planner.next_action(
                            env,
                            {"command_type": "go_to_waypoint", "waypoint_xy": subgoal_xy},
                        )
                    elif goal_xy is not None and rng.rand() > 0.5:
                        action = trajectory_planner.next_action(
                            env,
                            {"command_type": "go_to_waypoint", "waypoint_xy": goal_xy},
                        )
                    else:
                        action = random_safe_action(rng)
                elif args.songline_policy == "graph_path":
                    if bool(getattr(args, "oracle_controller", False)) and subgoal_xy is not None:
                        oracle_controller_activated = 1
                        active_maneuver_command_type = "oracle_controller"
                        action = _oracle_controller_action(env, trajectory_planner, subgoal_xy)
                    elif resume_to_goal_active and resume_to_goal_steps_left > 0:
                        command = {
                            "command_type": "resume_to_goal",
                            "waypoint_xy": goal_xy if goal_xy is not None else subgoal_xy,
                            "final_exit_mode": args.final_exit_mode,
                        }
                        active_maneuver_command_type = str(command.get("command_type"))
                        action = trajectory_planner.next_action(env, command)
                    elif final_exit_active and final_exit_steps_left > 0:
                        command = {
                            "command_type": "final_exit_maneuver",
                            "waypoint_xy": goal_xy if goal_xy is not None else subgoal_xy,
                            "hazard_commit_dir": final_exit_dir,
                            "final_exit_mode": args.final_exit_mode,
                        }
                        active_maneuver_command_type = str(command.get("command_type"))
                        action = trajectory_planner.next_action(env, command)
                    elif exit_hazard_commit_active and exit_hazard_commit_steps_left > 0:
                        command = {
                            "command_type": "exit_hazard_commit",
                            "waypoint_xy": goal_xy if goal_xy is not None else subgoal_xy,
                            "hazard_commit_dir": exit_hazard_commit_dir,
                        }
                        active_maneuver_command_type = str(command.get("command_type"))
                        action = trajectory_planner.next_action(env, command)
                    elif local_resource_plan is not None:
                        local_resource_guidance_used = 1
                        if bool(local_resource_plan.get("hold_position", False)):
                            active_maneuver_command_type = "hold_local_resource"
                            action = 0
                        else:
                            local_waypoint_xy = np.asarray(local_resource_plan["waypoint_xy"], dtype=np.int32)
                            active_maneuver_command_type = "go_to_local_resource"
                            action = trajectory_planner.next_action(
                                env,
                                {"command_type": "go_to_waypoint", "waypoint_xy": local_waypoint_xy},
                            )
                    elif subgoal_xy is not None and rng.rand() > args.epsilon:
                        if hazard_commit_active and hazard_commit_steps_left > 0:
                            command = {
                                "command_type": "committed_corridor_cross",
                                "waypoint_xy": subgoal_xy,
                                "hazard_commit_dir": hazard_commit_dir,
                            }
                        else:
                            command = active_maneuver_command or {"command_type": "follow_graph_path", "waypoint_xy": subgoal_xy}
                        active_maneuver_command_type = str(command.get("command_type"))
                        action = trajectory_planner.next_action(env, command)
                    elif goal_xy is not None:
                        active_maneuver_command_type = "go_to_waypoint"
                        action = trajectory_planner.next_action(
                            env,
                            {"command_type": "go_to_waypoint", "waypoint_xy": goal_xy},
                        )
                    else:
                        active_maneuver_command_type = "random"
                        action = random_safe_action(rng)
                else:
                    raise ValueError(f"Unknown songline policy: {args.songline_policy}")

            if token_label == "gap_aligned":
                phase_flags["gap_aligned"] = 1
            elif token_label == "safe_crossing":
                phase_flags["safe_crossing"] = 1
            elif token_label == "post_hazard":
                phase_flags["post_hazard"] = 1
                post_hazard_armed = 1
            if active_maneuver_command_type == "final_exit_maneuver":
                phase_flags["final_exit_maneuver"] = 1
            elif active_maneuver_command_type == "resume_to_goal":
                phase_flags["resume_to_goal"] = 1
                resume_to_goal_armed = 1

            obs, reward, terminated, truncated, info = env.step(action)
            step_info = dict(info or {})
            del obs, info

            total_step_idx += 1
            episode_return += float(reward)
            water_task_success = max(water_task_success, int(step_info.get("water_task_success", 0)))
            rest_task_success = max(rest_task_success, int(step_info.get("rest_task_success", 0)))
            agent_xy_new = np.array(env.unwrapped.agent_pos, dtype=np.int32)
            distance_after = None if goal_xy is None else manhattan(agent_xy_new, goal_xy)
            water_distance_after = None if water_xy is None else manhattan(agent_xy_new, water_xy)
            rest_distance_after = None if rest_xy is None else manhattan(agent_xy_new, rest_xy)
            delta_distance = None
            if distance_before is not None and distance_after is not None:
                delta_distance = float(distance_before - distance_after)
                if post_hazard_armed and delta_distance > 0.0:
                    has_post_hazard_progress = 1
                    post_hazard_armed = 0
                if resume_to_goal_armed and delta_distance > 0.0:
                    has_resume_to_goal_progress = 1
                    resume_to_goal_armed = 0

            if args.agent_mode == "songline":
                if previous_goal_distance is not None and distance_after is not None:
                    improved = distance_after < previous_goal_distance
                    memory.record_plan_outcome(improved)

                transition_success = None
                transition_risk = None
                transition_cost = None
                if delta_distance is not None:
                    transition_success = 1.0 if delta_distance > 0.0 else 0.0
                    transition_cost = 1.0
                if args.token_source != "symbolic_hash":
                    post_scene = scene_encoder.encode(env)
                    transition_risk = scene_risk_proxy(post_scene)
                else:
                    post_scene = None

                memory.observe(
                    scene_token=scene_token,
                    scene_state=post_scene,
                    agent_state=agent_state,
                    step_info={
                        "phase": "post_action",
                        "step_idx": int(total_step_idx),
                        "previous_graph_node_id": None if prev_graph_node_id is None else int(prev_graph_node_id),
                        "current_graph_node_id": None if current_graph_node_id is None else int(current_graph_node_id),
                        "token_label": str(token_label),
                        "pose_xy": agent_xy_new,
                        "goal_xy": goal_xy,
                        "reward": float(reward),
                        "progress": delta_distance,
                        "risk": transition_risk,
                        "success": 1.0 if float(reward) > 0.0 else 0.0,
                        "comfort_cost": scene_comfort_proxy(post_scene) if post_scene is not None else None,
                        "goal_alignment": post_scene.route_context.goal_alignment if post_scene is not None else None,
                        "transition_success": transition_success,
                        "transition_risk": transition_risk,
                        "transition_cost": transition_cost,
                        "context_label": str(getattr(agent_state, "task_phase", token_label)),
                        "active_intent": None if active_intent_type is None else str(active_intent_type.value),
                        "intent_reason": str(active_intent_reason),
                        "semantic_tags": {} if scene_token is None else dict(getattr(scene_token, "semantic_tags", {})),
                        "observations": {
                            "pos_before": [int(agent_xy[0]), int(agent_xy[1])],
                            "pos_after": [int(agent_xy_new[0]), int(agent_xy_new[1])],
                            "distance_before": None if distance_before is None else int(distance_before),
                            "distance_after": None if distance_after is None else int(distance_after),
                            "planner_query_intent": None if active_planner_debug is None else active_planner_debug.get("intent_type"),
                            "planner_query_tag_name": None if active_planner_debug is None else active_planner_debug.get("query_tag_name"),
                            "target_node_id": None if active_target_node_id is None else int(active_target_node_id),
                            "goal_rejoin_target_source": str(trace_goal_rejoin_target_source),
                        },
                        "outcome": {
                            "reward": float(reward),
                            "success_signal": int(float(reward) > 0.0),
                            "delta_distance": 0.0 if delta_distance is None else float(delta_distance),
                            "water_task_success": int(water_task_success),
                            "rest_task_success": int(rest_task_success),
                        },
                    },
                )

            if should_use_goal_rejoin_guard(args):
                if str(agent_state.task_phase) == "hazard_navigation":
                    goal_rejoin_guard_active = False
                    goal_rejoin_guard_steps_left = 0
                    goal_rejoin_guard_best_distance = None
                elif goal_rejoin_guard_active:
                    if distance_after is not None:
                        if goal_rejoin_guard_best_distance is None or distance_after < goal_rejoin_guard_best_distance:
                            goal_rejoin_guard_best_distance = distance_after
                        elif distance_after > goal_rejoin_guard_best_distance + 1:
                            goal_rejoin_guard_active = False
                            goal_rejoin_guard_steps_left = 0
                            goal_rejoin_guard_best_distance = None
                    if goal_rejoin_guard_active and goal_rejoin_guard_steps_left > 0:
                        goal_rejoin_guard_steps_left -= 1
                    if goal_rejoin_guard_steps_left <= 0:
                        goal_rejoin_guard_active = False

            if hazard_commit_active:
                still_hazard = hazard_phase_active
                front_safe_now = False
                if args.agent_mode == "songline" and scene_encoder is not None:
                    if post_scene is None:
                        post_scene = scene_encoder.encode(env)
                    post_risk = post_scene.risk_features
                    still_hazard = bool(
                        int(post_risk.get("hazard_front", 0.0)) == 1
                        or int(post_risk.get("hazard_near", 0.0)) == 1
                    )
                    front_safe_now = int(post_scene.risk_features.get("front_safe", 0.0)) == 1
                if still_hazard and front_safe_now and hazard_commit_steps_left > 0:
                    hazard_commit_steps_left -= 1
                else:
                    hazard_commit_active = False
                    hazard_commit_dir = None
                    hazard_commit_steps_left = 0
                if hazard_commit_steps_left <= 0:
                    hazard_commit_active = False
                    hazard_commit_dir = None

            if exit_hazard_commit_active:
                still_hazard = hazard_phase_active
                if args.agent_mode == "songline" and scene_encoder is not None:
                    post_scene = scene_encoder.encode(env)
                    post_risk = post_scene.risk_features
                    still_hazard = bool(
                        int(post_risk.get("hazard_front", 0.0)) == 1
                        or int(post_risk.get("hazard_near", 0.0)) == 1
                    )
                if still_hazard and exit_hazard_commit_steps_left > 0:
                    exit_hazard_commit_steps_left -= 1
                else:
                    exit_hazard_commit_active = False
                    exit_hazard_commit_dir = None
                    exit_hazard_commit_steps_left = 0
                if exit_hazard_commit_steps_left <= 0:
                    exit_hazard_commit_active = False
                    exit_hazard_commit_dir = None

            if final_exit_active:
                maintained_progress = True
                if distance_before is not None and distance_after is not None:
                    maintained_progress = distance_after <= distance_before
                if maintained_progress and final_exit_steps_left > 0:
                    final_exit_steps_left -= 1
                else:
                    final_exit_active = False
                    final_exit_dir = None
                    final_exit_steps_left = 0
                if final_exit_steps_left <= 0:
                    if maintained_progress:
                        resume_to_goal_active = True
                        # Give the bridge one full future action-selection step to fire.
                        resume_to_goal_steps_left = max(resume_to_goal_steps_left, 2)
                    final_exit_active = False
                    final_exit_dir = None

            if resume_to_goal_active:
                if resume_to_goal_steps_left > 0:
                    resume_to_goal_steps_left -= 1
                if resume_to_goal_steps_left <= 0:
                    resume_to_goal_active = False

            if args.agent_mode == "greedy_episodic":
                episodic_observe(ep_memory, agent_xy_new, distance_before, distance_after)

            if active_subgoal_key is not None:
                if int(agent_xy_new[0]) == active_subgoal_key[0] and int(agent_xy_new[1]) == active_subgoal_key[1]:
                    subgoal_hits_this_episode += 1
                    if active_intervention_distance is not None and distance_after is not None:
                        distance_delta_sum += float(active_intervention_distance - distance_after)
                    active_subgoal_key = None
                    active_intervention_distance = None
                    active_target_node_id = None
                    active_next_node_id = None
                    active_maneuver_command = None
                    active_maneuver_command_type = None
                    active_planner_debug = None
                    hazard_commit_active = False
                    hazard_commit_dir = None
                    hazard_commit_steps_left = 0
                    exit_hazard_commit_active = False
                    exit_hazard_commit_dir = None
                    exit_hazard_commit_steps_left = 0
                    final_exit_active = False
                    final_exit_dir = None
                    final_exit_steps_left = 0
                    resume_to_goal_active = False
                    resume_to_goal_steps_left = 0
                    if args.agent_mode == "greedy_episodic" and ep_memory["active_waypoint"] is not None:
                        ep_memory["active_waypoint"] = None
                elif active_intervention_distance is not None and distance_after is not None:
                    if distance_after > active_intervention_distance + args.intervention_patience:
                        active_subgoal_key = None
                        active_intervention_distance = None
                        active_target_node_id = None
                        active_next_node_id = None
                        active_maneuver_command = None
                        active_maneuver_command_type = None
                        active_planner_debug = None
                        hazard_commit_active = False
                        hazard_commit_dir = None
                        hazard_commit_steps_left = 0
                        exit_hazard_commit_active = False
                        exit_hazard_commit_dir = None
                        exit_hazard_commit_steps_left = 0
                        final_exit_active = False
                        final_exit_dir = None
                        final_exit_steps_left = 0
                        resume_to_goal_active = False
                        resume_to_goal_steps_left = 0
                        if args.agent_mode == "greedy_episodic" and ep_memory["active_waypoint"] is not None:
                            ep_memory["active_waypoint"] = None

            if args.debug_trace and args.agent_mode == "songline":
                trace_enabled = args.debug_trace_env_filter in ("", args.env_id)
                if trace_enabled:
                    risk = {} if scene is None else scene.risk_features
                    planner_debug = trajectory_planner.debug_state() if hasattr(trajectory_planner, "debug_state") else {
                        "corridor_commit_active": 0,
                        "corridor_commit_dir": None,
                        "corridor_commit_steps_left": 0,
                    }
                    debug_trace_rows.append(
                        {
                            "episode": int(ep + 1),
                            "step": int(step + 1),
                            "token": token_label,
                            "prev_token": previous_token_label,
                            "action": int(action),
                            "pos_x": int(agent_xy[0]),
                            "pos_y": int(agent_xy[1]),
                            "next_pos_x": int(agent_xy_new[0]),
                            "next_pos_y": int(agent_xy_new[1]),
                            "front_cell": int(risk.get("front_cell", -1)),
                            "left_cell": int(risk.get("left_cell", -1)),
                            "right_cell": int(risk.get("right_cell", -1)),
                            "back_cell": int(risk.get("back_cell", -1)),
                            "distance_before": -1 if distance_before is None else int(distance_before),
                            "distance_after": -1 if distance_after is None else int(distance_after),
                            "delta_distance": 0.0 if delta_distance is None else float(delta_distance),
                            "subgoal_x": None if subgoal_xy is None else int(subgoal_xy[0]),
                            "subgoal_y": None if subgoal_xy is None else int(subgoal_xy[1]),
                            "intervention_active": int(active_subgoal_key is not None),
                            "reward": float(reward),
                            "graph_node_id": None if memory.current_phrase_id is None else int(memory.current_phrase_id),
                            "target_node_id": active_target_node_id,
                            "next_graph_node_id": active_next_node_id,
                            "maneuver_command_type": active_maneuver_command_type,
                            "planner_used_intent_query": int(bool(active_planner_debug and active_planner_debug.get("used_intent_query", False))),
                            "planner_query_intent": None if active_planner_debug is None else active_planner_debug.get("intent_type"),
                            "planner_resolved_active_intent_type": None if active_planner_debug is None else active_planner_debug.get("resolved_active_intent_type"),
                            "planner_query_tag_name": None if active_planner_debug is None else active_planner_debug.get("query_tag_name"),
                            "planner_candidate_node_ids": "[]" if active_planner_debug is None else json.dumps(active_planner_debug.get("candidate_node_ids", [])),
                            "planner_candidate_base_utilities": "{}" if active_planner_debug is None else json.dumps(active_planner_debug.get("candidate_base_utilities", {}), sort_keys=True),
                            "planner_candidate_tag_confidences": "{}" if active_planner_debug is None else json.dumps(active_planner_debug.get("candidate_tag_confidences", {}), sort_keys=True),
                            "planner_candidate_concept_membership": "{}" if active_planner_debug is None else json.dumps(active_planner_debug.get("candidate_concept_membership", {}), sort_keys=True),
                            "planner_concept_query_debug": "{}" if active_planner_debug is None else json.dumps(active_planner_debug.get("concept_query_debug", {}), sort_keys=True),
                            "planner_selected_tag_confidence": None if active_planner_debug is None else active_planner_debug.get("selected_tag_confidence"),
                            "planner_selected_node_semantic_tag_confidence": "{}" if active_planner_debug is None else json.dumps(active_planner_debug.get("selected_node_semantic_tag_confidence", {}), sort_keys=True),
                            "planner_selected_plan_utility": None if active_planner_debug is None else float(active_planner_debug.get("selected_plan_utility", 0.0)),
                            "intent_switched": int(trace_intent_switched),
                            "forced_intent_replan": int(trace_forced_intent_replan),
                            "forced_goal_rejoin_replan": int(trace_forced_goal_rejoin_replan),
                            "exited_hazard_recovery_intent": int(trace_exited_hazard_recovery_intent),
                            "goal_rejoin_handoff_suppressed": int(trace_goal_rejoin_handoff_suppressed),
                            "goal_rejoin_target_materialized": int(trace_goal_rejoin_target_materialized),
                            "goal_rejoin_target_source": trace_goal_rejoin_target_source,
                            "goal_rejoin_fallback_used": int(trace_goal_rejoin_fallback_used),
                            "stable_rejoin_waypoint_used": int(trace_stable_rejoin_waypoint_used),
                            "stable_rejoin_waypoint_x": trace_stable_rejoin_waypoint_x,
                            "stable_rejoin_waypoint_y": trace_stable_rejoin_waypoint_y,
                            "rejoin_target_hazard_adjacent": int(trace_rejoin_target_hazard_adjacent),
                            "rejoin_target_goal_alignment": float(trace_rejoin_target_goal_alignment),
                            "goal_rejoin_graph_node_considered": int(trace_goal_rejoin_graph_node_considered),
                            "goal_rejoin_graph_node_accepted": int(trace_goal_rejoin_graph_node_accepted),
                            "goal_rejoin_graph_node_rejected": int(trace_goal_rejoin_graph_node_rejected),
                            "goal_rejoin_graph_node_reject_reason": trace_goal_rejoin_graph_node_reject_reason,
                            "goal_rejoin_graph_node_goal_region_confidence": float(trace_goal_rejoin_graph_node_goal_region_confidence),
                            "goal_rejoin_graph_node_hazard_adjacent": int(trace_goal_rejoin_graph_node_hazard_adjacent),
                            "goal_rejoin_graph_node_goal_alignment": float(trace_goal_rejoin_graph_node_goal_alignment),
                            "goal_rejoin_stable_waypoint_available": int(trace_goal_rejoin_stable_waypoint_available),
                            "previous_active_intent": trace_previous_active_intent,
                            "new_active_intent": trace_new_active_intent,
                            "intent_switch_reason": trace_intent_switch_reason,
                            "previous_target_node_id": trace_previous_target_node_id,
                            "new_target_node_id": trace_new_target_node_id,
                            "agent_state_thirst": float(agent_state.thirst),
                            "agent_state_energy": float(agent_state.energy),
                            "agent_state_risk_budget": float(agent_state.risk_budget),
                            "agent_state_task_phase": str(agent_state.task_phase),
                            "agent_state_active_intent": None if active_intent_type is None else str(active_intent_type.value),
                            "water_visible": float(risk.get("water_visible", 0.0)),
                            "water_accessible": float(risk.get("water_accessible", 0.0)),
                            "water_confidence_local": float(risk.get("water_confidence_local", 0.0)),
                            "water_pattern_match": float(risk.get("water_pattern_match", 0.0)),
                            "water_neighbor_context": float(risk.get("water_neighbor_context", 0.0)),
                            "rest_visible": float(risk.get("rest_visible", 0.0)),
                            "rest_accessible": float(risk.get("rest_accessible", 0.0)),
                            "rest_confidence_local": float(risk.get("rest_confidence_local", 0.0)),
                            "rest_pattern_match": float(risk.get("rest_pattern_match", 0.0)),
                            "rest_neighbor_context": float(risk.get("rest_neighbor_context", 0.0)),
                            "goal_visible": int(risk.get("goal_visible", 0.0)),
                            "hazard_front": int(risk.get("hazard_front", 0.0)),
                            "hazard_near": int(risk.get("hazard_near", 0.0)),
                            "front_safe": int(risk.get("front_safe", 0.0)),
                            "narrow_safe_channel": int(risk.get("narrow_safe_channel", 0.0)),
                            "goal_heading_alignment": float(risk.get("goal_heading_alignment", 0.0)),
                            "hazard_phase_active": int(hazard_phase_active),
                            "corridor_commit_active": int(hazard_commit_active),
                            "corridor_commit_dir": hazard_commit_dir,
                            "corridor_commit_steps_left": int(hazard_commit_steps_left),
                            "exit_hazard_commit_active": int(exit_hazard_commit_active),
                            "exit_hazard_commit_dir": exit_hazard_commit_dir,
                            "exit_hazard_commit_steps_left": int(exit_hazard_commit_steps_left),
                            "final_exit_active": int(final_exit_active),
                            "final_exit_dir": final_exit_dir,
                            "final_exit_steps_left": int(final_exit_steps_left),
                            "resume_to_goal_active": int(resume_to_goal_active),
                            "resume_to_goal_steps_left": int(resume_to_goal_steps_left),
                            "goal_rejoin_guard_active": int(goal_rejoin_guard_active),
                            "goal_rejoin_guard_steps_left": int(goal_rejoin_guard_steps_left),
                        }
                    )
                    previous_token_label = token_label

            if record_demo_episode:
                should_capture_demo = bool(
                    ((step + 1) % max(1, int(getattr(args, "demo_frame_stride", 1))) == 0)
                    or int(trace_forced_goal_rejoin_replan) == 1
                    or float(reward) > 0.0
                    or terminated
                    or truncated
                )
                if should_capture_demo:
                    frame = env.render()
                    if frame is not None:
                        event_bits = []
                        if int(trace_forced_goal_rejoin_replan) == 1:
                            event_bits.append("forced_goal_rejoin")
                        if str(trace_goal_rejoin_target_source) not in ("none", ""):
                            event_bits.append(f"source={trace_goal_rejoin_target_source}")
                        if float(reward) > 0.0:
                            event_bits.append("goal_reached")
                        demo_frames.append(np.asarray(frame, dtype=np.uint8))
                        demo_frame_meta.append(
                            {
                                "episode": int(ep + 1),
                                "step": int(step + 1),
                                "token": token_label,
                                "action": int(action),
                                "intent": None if active_intent_type is None else str(active_intent_type.value),
                                "rejoin_source": str(trace_goal_rejoin_target_source),
                                "hazard_adjacent": int(trace_rejoin_target_hazard_adjacent),
                                "goal_alignment": float(trace_rejoin_target_goal_alignment),
                                "pos": tuple(int(v) for v in agent_xy_new),
                                "subgoal": None if subgoal_xy is None else tuple(int(v) for v in subgoal_xy),
                                "distance_after": None if distance_after is None else int(distance_after),
                                "reward": float(reward),
                                "water_distance": None if water_distance_after is None else int(water_distance_after),
                                "rest_distance": None if rest_distance_after is None else int(rest_distance_after),
                                "event": ",".join(event_bits),
                            }
                        )

            if distance_after is not None:
                previous_goal_distance = distance_after
            if intent_replan_cooldown_left > 0:
                intent_replan_cooldown_left -= 1

            if reward > 0:
                success = 1
                if goal_xy is not None:
                    subgoal_xy = goal_xy.copy()

            if terminated or truncated:
                break

        edge_count = 0 if memory is None else sum(len(v) for v in memory.edges.values())
        intervention_rate = 0.0
        if args.agent_mode == "songline":
            intervention_rate = safe_rate(memory.interventions, memory.intervention_attempts)
            if args.songline_policy == "no_override":
                intervention_rate = safe_rate(no_override_suggestions, max(1, step_count))
        elif args.agent_mode == "greedy_episodic":
            intervention_rate = safe_rate(interventions_this_episode, max(1, step_count))

        plan_hit_rate = 0.0 if memory is None else safe_rate(memory.plan_hits, memory.plan_total)
        phrase_length_mean = get_phrase_length_mean(memory)
        node_reuse_rate = 0.0
        if args.agent_mode == "songline" and memory is not None:
            reused = sum(1 for node in memory.nodes.values() if node["visits"] > 1)
            node_reuse_rate = safe_rate(reused, len(memory.nodes))

        new_nodes = 0 if memory is None else len(memory.nodes) - new_nodes_start
        graph_path_length_mean = float(np.mean(graph_path_lengths)) if graph_path_lengths else 0.0
        subgoal_reach_rate = safe_rate(subgoal_hits_this_episode, interventions_this_episode)
        distance_delta_per_intervention = safe_rate(distance_delta_sum, interventions_this_episode)
        max_phase_depth = 0
        if phase_flags["gap_aligned"]:
            max_phase_depth = 1
        if phase_flags["safe_crossing"]:
            max_phase_depth = 2
        if phase_flags["post_hazard"]:
            max_phase_depth = 3
        if phase_flags["final_exit_maneuver"]:
            max_phase_depth = 4
        if phase_flags["resume_to_goal"]:
            max_phase_depth = 5
        episode_query_metrics = compute_episode_query_metrics(
            memory,
            episode_id=int(ep + 1),
            success=int(success),
        )

        episode_metrics = {
            "episode": ep + 1,
            "env_id": args.env_id,
            "task_mode": getattr(args, "task_mode", "default"),
            "task_mission": str(task_info.get("task_mission", "")),
            "episode_intent_type_effective": str(effective_intent_type_name(args)),
            "semantic_target_type": task_info.get("semantic_target_type"),
            "semantic_target_color": task_info.get("semantic_target_color"),
            "semantic_target_pos": task_info.get("semantic_target_pos"),
            "change_active": int(change_active),
            "env_change_mode": args.env_change_mode,
            "change_after_episode": int(args.change_after_episode),
            "intent_mode": args.intent_mode,
            "intent_selection_mode": args.intent_selection_mode,
            "intent_type": args.intent_type,
            "intent_handoff_mode": args.intent_handoff_mode,
            "goal_rejoin_guard_mode": args.goal_rejoin_guard_mode,
            "goal_rejoin_target_mode": args.goal_rejoin_target_mode,
            "semantic_retrieval_mode": getattr(args, "semantic_retrieval_mode", "concept_recall_v1"),
            "oracle_retrieval_enabled": int(bool(getattr(args, "oracle_retrieval", False))),
            "oracle_materialization_enabled": int(bool(getattr(args, "oracle_materialization", False))),
            "oracle_controller_enabled": int(bool(getattr(args, "oracle_controller", False))),
            "semantic_tag_dropout_prob": float(getattr(args, "semantic_tag_dropout_prob", 0.0)),
            "semantic_tag_false_positive_prob": float(getattr(args, "semantic_tag_false_positive_prob", 0.0)),
            "semantic_tag_false_positive_value": float(getattr(args, "semantic_tag_false_positive_value", 0.35)),
            "water_success_radius": int(getattr(args, "water_success_radius", 1)),
            "rest_success_radius": int(getattr(args, "rest_success_radius", 1)),
            "thirst_on_threshold": float(getattr(args, "thirst_on_threshold", 0.10)),
            "thirst_off_threshold": float(getattr(args, "thirst_off_threshold", 0.04)),
            "water_local_activation_threshold": float(getattr(args, "water_local_activation_threshold", 0.0)),
            "water_local_hold_threshold": float(getattr(args, "water_local_hold_threshold", 0.0)),
            "rest_energy_on_threshold": float(getattr(args, "rest_energy_on_threshold", 0.95)),
            "rest_energy_off_threshold": float(getattr(args, "rest_energy_off_threshold", 0.98)),
            "rest_local_activation_threshold": float(getattr(args, "rest_local_activation_threshold", 0.0)),
            "rest_local_hold_threshold": float(getattr(args, "rest_local_hold_threshold", 0.0)),
            "local_resource_guidance_enabled": int(local_resource_guidance_enabled(args)),
            "goal_rejoin_fallback_assists_enabled": int(goal_rejoin_fallback_assists_enabled(args)),
            "oracle_retrieval_activated": int(oracle_retrieval_activated),
            "oracle_materialization_activated": int(oracle_materialization_activated),
            "oracle_controller_activated": int(oracle_controller_activated),
            "intent_active": int(args.intent_mode != "none"),
            "has_goal_rejoin_materialization_failure": int(has_goal_rejoin_materialization_failure),
            "water_task_success": int(water_task_success),
            "rest_task_success": int(rest_task_success),
            "active_intent_type": None if active_intent_type is None else str(active_intent_type.value),
            "intent_switch_reason": str(active_intent_reason),
            "agent_task_phase": str(agent_state.task_phase),
            "agent_thirst": float(agent_state.thirst),
            "agent_energy": float(agent_state.energy),
            "agent_risk_budget": float(agent_state.risk_budget),
            "agent_mode": args.agent_mode,
            "songline_policy": args.songline_policy,
            "method": method_name,
            "seed": args.seed,
            "return": float(episode_return),
            "steps_to_goal": int(step_count),
            "steps": int(step_count),
            "success": int(success),
            "intervention_rate": float(intervention_rate),
            "plan_hit_rate": float(plan_hit_rate),
            "graph_nodes": 0 if memory is None else int(len(memory.nodes)),
            "graph_edges": int(edge_count),
            "phrase_length_mean": float(phrase_length_mean),
            "subgoal_reach_rate": float(subgoal_reach_rate),
            "goal_distance_delta_per_intervention": float(distance_delta_per_intervention),
            "node_reuse_rate": float(node_reuse_rate),
            "new_nodes_per_episode": int(new_nodes),
            "graph_path_length": float(graph_path_length_mean),
            "has_gap_aligned": int(phase_flags["gap_aligned"]),
            "has_safe_crossing": int(phase_flags["safe_crossing"]),
            "has_post_hazard": int(phase_flags["post_hazard"]),
            "has_final_exit_maneuver": int(phase_flags["final_exit_maneuver"]),
            "has_resume_to_goal": int(phase_flags["resume_to_goal"]),
            "has_post_hazard_progress": int(has_post_hazard_progress),
            "has_resume_to_goal_progress": int(has_resume_to_goal_progress),
            "post_hazard_to_success": int(phase_flags["post_hazard"] and success),
            "resume_to_goal_to_success": int(phase_flags["resume_to_goal"] and success),
            "max_phase_depth": int(max_phase_depth),
            "local_resource_guidance_used": int(local_resource_guidance_used),
            "goal_rejoin_fallback_assist_used": int(goal_rejoin_fallback_assist_used),
        }
        episode_metrics.update(episode_query_metrics)

        run_summary["episode_returns"].append(float(episode_return))
        run_summary["episode_lengths"].append(int(step_count))
        run_summary["successes"].append(int(success))
        if change_active:
            run_summary["successes_post_change"].append(int(success))
        else:
            run_summary["successes_pre_change"].append(int(success))
        run_summary["graph_nodes"].append(episode_metrics["graph_nodes"])
        run_summary["graph_edges"].append(episode_metrics["graph_edges"])
        run_summary["intervention_rate"].append(float(intervention_rate))
        run_summary["plan_hit_rate"].append(float(plan_hit_rate))
        run_summary["phrase_length_mean"].append(float(phrase_length_mean))
        run_summary["subgoal_reached"].append(float(subgoal_reach_rate))
        run_summary["goal_distance_delta_per_intervention"].append(float(distance_delta_per_intervention))
        run_summary["node_reuse_rate"].append(float(node_reuse_rate))
        run_summary["new_nodes_per_episode"].append(int(new_nodes))
        run_summary["graph_path_length"].append(float(graph_path_length_mean))
        run_summary["has_gap_aligned"].append(int(phase_flags["gap_aligned"]))
        run_summary["has_safe_crossing"].append(int(phase_flags["safe_crossing"]))
        run_summary["has_post_hazard"].append(int(phase_flags["post_hazard"]))
        run_summary["has_final_exit_maneuver"].append(int(phase_flags["final_exit_maneuver"]))
        run_summary["has_resume_to_goal"].append(int(phase_flags["resume_to_goal"]))
        run_summary["has_post_hazard_progress"].append(int(has_post_hazard_progress))
        run_summary["has_resume_to_goal_progress"].append(int(has_resume_to_goal_progress))
        run_summary["post_hazard_to_success"].append(int(phase_flags["post_hazard"] and success))
        run_summary["resume_to_goal_to_success"].append(int(phase_flags["resume_to_goal"] and success))
        run_summary["max_phase_depth"].append(int(max_phase_depth))
        run_summary["query_attempt_count"].append(int(episode_query_metrics["query_attempt_count"]))
        run_summary["query_nonempty_rate"].append(float(episode_query_metrics["query_nonempty_rate"]))
        run_summary["retrieval_precision_at_k"].append(float(episode_query_metrics["retrieval_precision_at_k"]))
        run_summary["query_satisfaction_rate"].append(float(episode_query_metrics["query_satisfaction_rate"]))
        run_summary["semantic_target_materialization_rate"].append(float(episode_query_metrics["semantic_target_materialization_rate"]))
        run_summary["semantic_target_materialized_any"].append(int(episode_query_metrics["semantic_target_materialized_any"]))
        run_summary["post_retrieval_completion"].append(int(episode_query_metrics["post_retrieval_completion"]))
        run_summary["local_resource_guidance_used"].append(int(local_resource_guidance_used))
        run_summary["goal_rejoin_fallback_assist_used"].append(int(goal_rejoin_fallback_assist_used))
        run_summary["retrieval_failure_empty"].append(int(episode_query_metrics["retrieval_failure_empty"]))
        run_summary["retrieval_failure_unsatisfied"].append(int(episode_query_metrics["retrieval_failure_unsatisfied"]))
        run_summary["semantic_materialization_failure"].append(int(episode_query_metrics["semantic_materialization_failure"]))
        run_summary["control_failure_after_retrieval"].append(int(episode_query_metrics["control_failure_after_retrieval"]))
        run_summary["oracle_retrieval_activated"].append(int(oracle_retrieval_activated))
        run_summary["oracle_materialization_activated"].append(int(oracle_materialization_activated))
        run_summary["oracle_controller_activated"].append(int(oracle_controller_activated))
        run_summary["episode_metrics"].append(episode_metrics)
        if memory is not None and hasattr(memory, "finalize_episode"):
            memory.finalize_episode(
                {
                    "success": int(success),
                    "return": float(episode_return),
                    "steps": int(step_count),
                    "change_active": int(change_active),
                    "water_task_success": int(water_task_success),
                    "rest_task_success": int(rest_task_success),
                    "active_intent_type_final": None if active_intent_type is None else str(active_intent_type.value),
                    "intent_switch_reason_final": str(active_intent_reason),
                }
            )

        if verbose:
            print(
                f"Episode {ep + 1:03d} | "
                f"method={method_name} | "
                f"return={episode_return:.3f} | "
                f"steps={step_count:03d} | "
                f"success={success} | "
                f"nodes={episode_metrics['graph_nodes']} | "
                f"edges={episode_metrics['graph_edges']} | "
                f"subgoal_hit={subgoal_reach_rate:.3f}"
            )

    summary = summarise_run(run_summary, memory)
    summary.update(
        {
            "env_id": args.env_id,
            "task_mode": getattr(args, "task_mode", "default"),
            "agent_mode": args.agent_mode,
            "songline_policy": args.songline_policy,
            "method": method_name,
            "episodes": args.episodes,
            "max_steps": args.max_steps,
            "seed": args.seed,
            "env_change_mode": args.env_change_mode,
            "change_after_episode": int(args.change_after_episode),
            "intent_mode": args.intent_mode,
            "intent_selection_mode": args.intent_selection_mode,
            "intent_type": args.intent_type,
            "intent_handoff_mode": args.intent_handoff_mode,
            "goal_rejoin_guard_mode": args.goal_rejoin_guard_mode,
            "goal_rejoin_target_mode": args.goal_rejoin_target_mode,
            "semantic_retrieval_mode": getattr(args, "semantic_retrieval_mode", "concept_recall_v1"),
            "water_success_radius": int(getattr(args, "water_success_radius", 1)),
            "rest_success_radius": int(getattr(args, "rest_success_radius", 1)),
            "thirst_on_threshold": float(getattr(args, "thirst_on_threshold", 0.10)),
            "thirst_off_threshold": float(getattr(args, "thirst_off_threshold", 0.04)),
            "water_local_activation_threshold": float(getattr(args, "water_local_activation_threshold", 0.0)),
            "water_local_hold_threshold": float(getattr(args, "water_local_hold_threshold", 0.0)),
            "rest_energy_on_threshold": float(getattr(args, "rest_energy_on_threshold", 0.95)),
            "rest_energy_off_threshold": float(getattr(args, "rest_energy_off_threshold", 0.98)),
            "rest_local_activation_threshold": float(getattr(args, "rest_local_activation_threshold", 0.0)),
            "rest_local_hold_threshold": float(getattr(args, "rest_local_hold_threshold", 0.0)),
            "local_resource_guidance_enabled": int(local_resource_guidance_enabled(args)),
            "goal_rejoin_fallback_assists_enabled": int(goal_rejoin_fallback_assists_enabled(args)),
        }
    )

    if export_outputs:
        with open(os.path.join(args.out_dir, "episodes.json"), "w") as f:
            json.dump(run_summary["episode_metrics"], f, indent=2)

        if memory is not None:
            memory.export(args.out_dir, env_idx=0)

        export_run_summary(args.out_dir, run_summary)

        with open(os.path.join(args.out_dir, "summary.json"), "w") as f:
            json.dump(summary, f, indent=2)
        if args.debug_trace:
            export_debug_trace(args.out_dir, debug_trace_rows)
        if getattr(args, "record_demo", False):
            export_demo_artifacts(
                args.out_dir,
                demo_frames,
                demo_frame_meta,
                fps=int(getattr(args, "demo_fps", 3)),
            )

    env.close()
    return run_summary, summary


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--env_id", type=str, default="MiniGrid-Empty-Random-6x6-v0")
    parser.add_argument(
        "--task_mode",
        type=str,
        default="default",
        choices=["default", "water_search_v1", "rest_search_v1", "babyai_semantic_v1"],
    )
    parser.add_argument(
        "--agent_mode",
        type=str,
        default="songline",
        choices=["random", "greedy", "greedy_episodic", "songline"],
    )
    parser.add_argument(
        "--songline_policy",
        type=str,
        default="subgoal_controller",
        choices=["no_override", "subgoal_controller", "graph_path"],
    )
    parser.add_argument("--episodes", type=int, default=40)
    parser.add_argument("--max_steps", type=int, default=120)
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--epsilon", type=float, default=0.15)
    parser.add_argument("--suggest_every", type=int, default=8)
    parser.add_argument("--intervention_patience", type=int, default=4)
    parser.add_argument("--min_goal_visits", type=int, default=2)
    parser.add_argument("--top_k_goals", type=int, default=5)
    parser.add_argument("--graph_rollout_horizon", type=int, default=4)
    parser.add_argument(
        "--token_source",
        type=str,
        default="symbolic_hash",
        choices=["symbolic_hash", "scene_semantic", "scene_patch_hash"],
    )
    parser.add_argument(
        "--milestone_mode",
        type=str,
        default="none",
        choices=["none", "semantic_handoff_v1"],
    )
    parser.add_argument(
        "--final_exit_mode",
        type=str,
        default="none",
        choices=["none", "v1"],
    )
    parser.add_argument(
        "--graph_update_mode",
        type=str,
        default="static",
        choices=["static", "adaptive"],
    )
    parser.add_argument(
        "--intent_mode",
        type=str,
        default="none",
        choices=["none", "safe_exit_v1", "hazard_recovery_v1", "goal_region_v1", "water_v1", "rest_v1", "babyai_mission_v1"],
    )
    parser.add_argument(
        "--intent_selection_mode",
        type=str,
        default="fixed",
        choices=["fixed", "state_v1"],
    )
    parser.add_argument(
        "--intent_type",
        type=str,
        default="reach_safe_exit",
        choices=["reach_safe_exit", "hazard_recovery_exit", "find_goal_region", "find_water_source", "find_safe_rest_zone"],
    )
    parser.add_argument(
        "--intent_handoff_mode",
        type=str,
        default="none",
        choices=["none", "post_recovery_goal_v1"],
    )
    parser.add_argument(
        "--goal_rejoin_guard_mode",
        type=str,
        default="none",
        choices=["none", "debounce_v1"],
    )
    parser.add_argument("--goal_rejoin_guard_steps", type=int, default=4)
    parser.add_argument(
        "--goal_rejoin_target_mode",
        type=str,
        default="none",
        choices=["none", "fallback_goal_v1", "stable_waypoint_v1", "source_select_v1", "source_select_v2"],
    )
    parser.add_argument(
        "--semantic_retrieval_mode",
        type=str,
        default="concept_recall_v1",
        choices=["node_only", "concept_recall_v1", "concept_plan_v1"],
    )
    parser.add_argument(
        "--env_change_mode",
        type=str,
        default="none",
        choices=["none", "goal_shift_v1"],
    )
    parser.add_argument("--change_after_episode", type=int, default=-1)
    parser.add_argument("--scene_radius", type=int, default=1)
    parser.add_argument("--export_phase_metrics", action="store_true")
    parser.add_argument("--early_hazard_intervention", action="store_true")
    parser.add_argument("--commit_to_corridor", action="store_true")
    parser.add_argument("--disable_local_resource_guidance", action="store_true")
    parser.add_argument("--disable_goal_rejoin_fallback_assists", action="store_true")
    parser.add_argument("--oracle_retrieval", action="store_true")
    parser.add_argument("--oracle_materialization", action="store_true")
    parser.add_argument("--oracle_controller", action="store_true")
    parser.add_argument("--semantic_tag_dropout_prob", type=float, default=0.0)
    parser.add_argument("--semantic_tag_false_positive_prob", type=float, default=0.0)
    parser.add_argument("--semantic_tag_false_positive_value", type=float, default=0.35)
    parser.add_argument("--debug_trace", action="store_true")
    parser.add_argument("--debug_trace_env_filter", type=str, default="")
    parser.add_argument("--record_demo", action="store_true")
    parser.add_argument("--demo_episode", type=int, default=1)
    parser.add_argument("--demo_frame_stride", type=int, default=1)
    parser.add_argument("--demo_fps", type=int, default=3)
    parser.add_argument("--intent_replan_cooldown_steps", type=int, default=4)
    parser.add_argument("--water_success_radius", type=int, default=1)
    parser.add_argument("--rest_success_radius", type=int, default=1)
    parser.add_argument("--thirst_on_threshold", type=float, default=0.10)
    parser.add_argument("--thirst_off_threshold", type=float, default=0.04)
    parser.add_argument("--water_local_activation_threshold", type=float, default=0.0)
    parser.add_argument("--water_local_hold_threshold", type=float, default=0.0)
    parser.add_argument("--rest_energy_on_threshold", type=float, default=0.95)
    parser.add_argument("--rest_energy_off_threshold", type=float, default=0.98)
    parser.add_argument("--rest_local_activation_threshold", type=float, default=0.0)
    parser.add_argument("--rest_local_hold_threshold", type=float, default=0.0)
    parser.add_argument("--tokenizer_mode", type=str, default="hash_sign", choices=["argmax", "hash_sign"])
    parser.add_argument("--tokenizer_proj_dim", type=int, default=16)
    parser.add_argument("--out_dir", type=str, default="tmp/songline_minigrid")
    return parser.parse_args()


def main():
    args = parse_args()
    _, summary = run_songline_experiment(args, export_outputs=True, verbose=True)

    print("\nFinal summary:")
    for k, v in summary.items():
        print(f"{k}: {v}")


if __name__ == "__main__":
    main()
